#!/usr/bin/env python3
"""run_sections.py GTAIV.exe WORKDIR
Tests the INI-controlled sections (ArchiveLimit / VehicleBudget / PedBudget) on a flat image of the real exe:
every combination of switches, Overwrite / range rules, independence (one section failing or refusing must not stop or undo the
others), and forced VirtualProtect failures with all three sections on. After each run the patched image is compared byte for byte
with the pristine one (audit.py), so a section that is switched off must have changed nothing at all."""
import re, struct, subprocess, sys, os
exe, W = sys.argv[1], sys.argv[2]
here = os.path.dirname(os.path.abspath(__file__)); root = os.path.dirname(here)
os.makedirs(W, exist_ok=True)
hdr = open(os.path.join(root, 'src', 'profiles_gen.h')).read()
raw = open(exe, 'rb').read()
pe = struct.unpack_from('<I', raw, 0x3c)[0]; ts, = struct.unpack_from('<I', raw, pe + 8)
soi, = struct.unpack_from('<I', raw, pe + 24 + 56)
m = {int(a, 16): (t, int(c, 16)) for t, a, c in re.findall(r'static const Profile (\w+) = \{ "[^"]*", 0x([0-9a-f]+)u, 0x[0-9a-f]+u, 0x([0-9a-f]+)u,', hdr)}
tag, table_va = m[ts]
def block(n): return re.search(r'static const \w+ %s_%s\[\] = \{(.*?)\n\};' % (tag, n), hdr, re.S).group(1)
hooks = [int(a, 16) for a in re.findall(r'\{ 0x([0-9a-f]{8}), \d+, \d+, \{', block('hooks'))]
bv = {}
for what in ('ped', 'veh'):
    mm = re.search(r'static const BudgetVar %s_%s = \{ 0x([0-9a-f]+), (\d+)u, (\d+), \{([^}]*)\}' % (tag, what), hdr)
    bv[what] = (int(mm.group(1), 16), int(mm.group(2)), [int(x, 16) for x in mm.group(4).split(',')][:int(mm.group(3))])
PREF = 0x400000
pristine = os.path.join(W, 'sec_src_400000.bin'); ref_img = os.path.join(W, 'sec_ref_20000000.bin')
subprocess.check_call([sys.executable, os.path.join(here, 'mkimage.py'), exe, '0x400000', pristine], stdout=subprocess.DEVNULL)
subprocess.check_call([sys.executable, os.path.join(here, 'mkimage.py'), exe, '0x20000000', ref_img], stdout=subprocess.DEVNULL)
src = bytearray(open(pristine, 'rb').read())[:soi]
harness = os.path.join(here, 'harness')
subprocess.check_call(['sh', os.path.join(here, 'build_test.sh')])

STOCK = {'veh': bv['veh'][1], 'ped': bv['ped'][1]}
def rd(img, va): return struct.unpack_from('<I', img, va - PREF)[0]
def wr(img, va, v): struct.pack_into('<I', img, va - PREF, v)

fails = []
def report(name, ok, detail=''):
    print('%-34s %s %s' % (name, 'ok  ' if ok else 'FAIL', detail))
    if not ok: fails.append(name)

def run(name, img, ini, fail_at=None, full=False):
    """returns (stdout, dump_bytes, image_path); ini text gets [Harness] InstallOnly=1 unless full"""
    p = os.path.join(W, 'sec_%s.bin' % name); open(p, 'wb').write(img)
    ip = os.path.join(W, 'sec_%s.ini' % name)
    open(ip, 'w').write(ini + ('' if full else '\n[Harness]\nInstallOnly=1\n'))
    d = os.path.join(W, 'sec_%s_dump.bin' % name)
    if os.path.exists(d): os.remove(d)
    cmd = [harness, ref_img, '0x20000000', p, '0x400000', W, '@' + ip, d] + ([str(fail_at)] if fail_at is not None else [])
    r = subprocess.run(cmd, capture_output=True, text=True)
    return r, (open(d, 'rb').read() if os.path.exists(d) else b''), p

def audit(img_path, dump, r, arch, veh=None, ped=None, refcheck=True, tag_name='a'):
    dp = os.path.join(W, 'sec_audit_dump.bin'); open(dp, 'wb').write(dump)
    args = [sys.executable, '-I', os.path.join(here, 'audit.py'), img_path, dp, '0x400000']
    if arch:
        t = re.search(r'new table at (0x[0-9a-f]+)', r.stdout); n = re.search(r'-> (\d+) archives', r.stdout)
        if t and n: args += [t.group(1), n.group(1)]
    args.append('arch=%d' % (1 if arch else 0))
    if veh is not None: args.append('veh=%d' % veh)
    if ped is not None: args.append('ped=%d' % ped)
    if not refcheck: args.append('refcheck=0')
    a = subprocess.run(args, capture_output=True, text=True)
    return a.returncode == 0, a.stdout

def check(name, ini, arch, veh=None, ped=None, img=None, full=False, expect_log=(), refcheck=True, expect_rc=0):
    img = bytearray(src) if img is None else img
    r, dump, p = run(name, img, ini, full=full)
    ok_a, out = audit(p, dump, r, arch, veh, ped, refcheck)
    logok = all(s in r.stdout for s in expect_log)
    harness_ok = r.returncode == expect_rc or (expect_rc == 0 and 'SkipBudgetCheck' in ini)
    tot = re.search(r'TOTAL: pass=(\d+) fail=(\d+)', r.stdout)
    detail = ('pass=%s fail=%s' % tot.groups()) if tot and full else ''
    if not ok_a: detail += '\n' + out
    if not logok: detail += '  (log lacks: %s)' % [s for s in expect_log if s not in r.stdout]
    if not harness_ok: detail += '  (harness rc=%d)' % r.returncode
    report(name, ok_a and logok and harness_ok, detail)
    return r, dump

def sec(arch=None, veh=None, ped=None):
    """build ini text; each argument None = section absent, otherwise a dict of keys"""
    t = ''
    for n, d in (('ArchiveLimit', arch), ('VehicleBudget', veh), ('PedBudget', ped)):
        if d is not None: t += '[%s]\n' % n + ''.join('%s=%s\n' % kv for kv in d.items())
    return t

V, Pd = 120000000, 75000000
# ---- switches --------------------------------------------------------------------------------------------------------
check('default_ini_archives_only', sec(arch={'MaxArchives': 1023}), True, full=True, expect_log=['OK: 1023 archives enabled'])
check('empty_ini_uses_defaults', '', True, expect_log=['OK: 1023 archives enabled', '[VehicleBudget] disabled', '[PedBudget]     disabled'])
check('veh_only', sec(arch={'Enabled': 0}, veh={'Enabled': 1}), False, veh=V, expect_log=['[ArchiveLimit]  disabled', 'VehicleBudget: OK, set to 120000000'])
check('ped_only', sec(arch={'Enabled': 0}, ped={'Enabled': 1}), False, ped=Pd, expect_log=['PedBudget: OK, set to 75000000'])
check('both_budgets_no_archive', sec(arch={'Enabled': 0}, veh={'Enabled': 1}, ped={'Enabled': 1}), False, veh=V, ped=Pd)
check('budgets_custom_values', sec(arch={'Enabled': 0}, veh={'Enabled': 1, 'Value': 200000000}, ped={'Enabled': 1, 'Value': 90000000}), False, veh=200000000, ped=90000000)
check('all_three', sec(arch={'MaxArchives': 700}, veh={'Enabled': 1, 'Value': 150000000}, ped={'Enabled': 1, 'Value': 60000000}), True, veh=150000000, ped=60000000, full=True)
check('all_three_B11', sec(arch={'MaxArchives': 2047}, veh={'Enabled': 1}, ped={'Enabled': 1}), True, veh=V, ped=Pd, full=True)
check('archives_and_veh_only', sec(arch={'MaxArchives': 400}, veh={'Enabled': 1}), True, veh=V)
check('max255_budgets_still_apply', sec(arch={'MaxArchives': 255}, veh={'Enabled': 1}, ped={'Enabled': 1}), False, veh=V, ped=Pd, expect_log=['nothing to do'])
check('nothing_enabled', sec(arch={'Enabled': 0}, veh={'Enabled': 0}, ped={'Enabled': 0}), False, expect_log=['Nothing enabled'])
check('keys_case_insensitive', '[archivelimit]\nenabled=0\n[VEHICLEBUDGET]\nENABLED=1\nvalue=130000000\n', False, veh=130000000)

# ---- Overwrite / existing values -----------------------------------------------------------------------------------------
for what, key in (('veh', 'VehicleBudget'), ('ped', 'PedBudget')):
    va, stock, _ = bv[what]; default = V if what == 'veh' else Pd
    img = bytearray(src); wr(img, va, 80000000)             # another mod / exe patch has already changed it
    kw = lambda x: {what: x}
    check('%s_foreign_value_kept' % what, sec(arch={'Enabled': 0}, **{what: {'Enabled': 1}}), False, img=bytearray(img), **kw(80000000), expect_log=['Left alone'])
    check('%s_foreign_value_overwrite' % what, sec(arch={'Enabled': 0}, **{what: {'Enabled': 1, 'Overwrite': 1}}), False, img=bytearray(img), **kw(default), expect_log=['OK, set to'])
    check('%s_already_equal' % what, sec(arch={'Enabled': 0}, **{what: {'Enabled': 1, 'Value': 80000000}}), False, img=bytearray(img), **kw(80000000), expect_log=['nothing to do'])
    for val, good in ((999999, False), (1000000, True), (0, False), (2147483647, True), (2147483648, False), (4294967295, False)):
        check('%s_range_%d' % (what, val), sec(arch={'Enabled': 0}, **{what: {'Enabled': 1, 'Value': val}}), False, **kw(val if good else None),
              expect_log=[] if good else ['outside'], expect_rc=0 if good else 1)   # rejected value: install() reports 0 (nothing applied), image untouched
    # the budget dword is the only thing that may differ, and the stock value really is what the plan says
    report('%s_stock_value' % what, rd(src, va) == stock, '%d' % stock)

# ---- independence: a section that cannot run must not stop or undo the others --------------------------------------------------
all_on = sec(arch={'MaxArchives': 1023}, veh={'Enabled': 1}, ped={'Enabled': 1})
img = bytearray(src); site = bv['veh'][2][1]; img[site - PREF] ^= 0x04                 # one code reference of the vehicle budget points elsewhere
check('veh_ref_mismatch_others_run', all_on + '[Harness]\nSkipBudgetCheck=1\n', True, ped=Pd, img=img, refcheck=False, expect_log=['MISMATCH at VehicleBudget reference', 'OK: 1023 archives', 'PedBudget: OK'])
img = bytearray(src); site = bv['ped'][2][0]; img[site - PREF + 1] ^= 0x01
check('ped_ref_mismatch_others_run', all_on + '[Harness]\nSkipBudgetCheck=1\n', True, veh=V, img=img, refcheck=False, expect_log=['MISMATCH at PedBudget reference', 'VehicleBudget: OK'])
img = bytearray(src); img[hooks[2] - PREF] ^= 0x40                                       # archive hook bytes changed by something else
check('archive_hook_mismatch_budgets_run', all_on, False, veh=V, ped=Pd, img=img, expect_log=['MISMATCH at', 'VehicleBudget: OK', 'PedBudget: OK'])
img = bytearray(src); wr(img, table_va + 0x98, 0xFFFFFFFF)                               # table already initialised: plugin loaded too late
check('archive_too_late_budgets_run', all_on, False, veh=V, ped=Pd, img=img, expect_log=['loaded too late', 'VehicleBudget: OK', 'PedBudget: OK'])
# unsupported exe: nothing at all may change, even with every section on
img = bytearray(src); struct.pack_into('<I', img, pe + 8, ts ^ 1)
r, dump, p = run('unsupported', img, all_on)
report('unsupported_build_nothing_changes', dump[:len(img)] == bytes(img) and 'install() returned 0' in r.stdout and 'not a supported build' in r.stdout)

# ---- forced VirtualProtect failures with all three sections on ------------------------------------------------------------------
ini_all = sec(arch={'MaxArchives': 1023}, veh={'Enabled': 1}, ped={'Enabled': 1})
r0, good, _ = run('sweep_all', bytearray(src), ini_all)
npatch = int(re.search(r'\((\d+) patches applied', r0.stdout).group(1))
_, d_vp, _ = run('sweep_vp', bytearray(src), sec(arch={'Enabled': 0}, veh={'Enabled': 1}, ped={'Enabled': 1}))
_, d_ap, _ = run('sweep_ap', bytearray(src), sec(arch={'MaxArchives': 1023}, ped={'Enabled': 1}))
_, d_av, _ = run('sweep_av', bytearray(src), sec(arch={'MaxArchives': 1023}, veh={'Enabled': 1}))
# call 0 seals the stub memory (read/write -> execute/read); then two calls per patch write, then the budgets
n_calls = 1 + 2 * (npatch + 2) + 3
bad = 0
for k in range(n_calls):
    r, dump, _ = run('sweep', bytearray(src), ini_all, fail_at=k)
    j = k - 1
    if k == 0:                 expect = d_vp                              # stubs can't be sealed -> archive section skipped, budgets still applied
    elif j < 2 * npatch:       expect = d_vp if j % 2 == 0 else good      # archive write fails -> whole archive section rolled back, budgets still applied
    elif j == 2 * npatch:      expect = d_ap                              # vehicle budget write fails -> archives + ped
    elif j == 2 * npatch + 2:  expect = d_av                              # ped budget write fails -> archives + vehicle
    else:                      expect = good                              # a failed "restore protection" call is harmless
    if dump != expect:
        bad += 1; print('  vpfail at call %d: image differs from the expected outcome' % k)
report('vp_failure_sweep (%d calls)' % n_calls, bad == 0, '%d unexpected' % bad)

print('SECTION TESTS', 'FAILED: ' + ', '.join(fails) if fails else 'PASSED')
sys.exit(1 if fails else 0)
