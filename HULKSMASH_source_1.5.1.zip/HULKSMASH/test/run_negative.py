#!/usr/bin/env python3
"""run_negative.py GTAIV.exe WORKDIR
Corrupts a copy of the flat image in ways a different/modified exe would differ, and checks that the plugin refuses to patch
(image byte-identical afterwards), plus forced VirtualProtect failures at every call index (all changes rolled back)."""
import re, struct, subprocess, sys, os
exe, W = sys.argv[1], sys.argv[2]
here = os.path.dirname(os.path.abspath(__file__)); root = os.path.dirname(here)
os.makedirs(W, exist_ok=True)
hdr = open(os.path.join(root, 'src', 'profiles_gen.h')).read()
raw = open(exe, 'rb').read()
pe = struct.unpack_from('<I', raw, 0x3c)[0]; ts, = struct.unpack_from('<I', raw, pe + 8)
m = {int(a, 16): (t, int(c, 16)) for t, a, c in re.findall(r'static const Profile (\w+) = \{ "[^"]*", 0x([0-9a-f]+)u, 0x[0-9a-f]+u, 0x([0-9a-f]+)u,', hdr)}
tag, table_va = m[ts]
def block(n): return re.search(r'static const \w+ %s_%s\[\] = \{(.*?)\n\};' % (tag, n), hdr, re.S).group(1)
body = [int(a, 16) for a in re.findall(r'\{0x([0-9a-f]{8}),0x', block('body'))]
hooks = [int(a, 16) for a in re.findall(r'\{ 0x([0-9a-f]{8}), \d+, \d+, \{', block('hooks'))]
bps = [(int(a, 16), int(o)) for a, o in re.findall(r'\{ 0x([0-9a-f]{8}), \d+, (\d+), \d, \d+, \{', block('bp'))]
PREF = 0x400000
base_img = os.path.join(W, 'neg_src_400000.bin'); ref_img = os.path.join(W, 'neg_ref_20000000.bin')
subprocess.check_call([sys.executable, os.path.join(here, 'mkimage.py'), exe, '0x400000', base_img], stdout=subprocess.DEVNULL)
subprocess.check_call([sys.executable, os.path.join(here, 'mkimage.py'), exe, '0x20000000', ref_img], stdout=subprocess.DEVNULL)
soi, = struct.unpack_from('<I', raw, pe + 24 + 56)
src = bytearray(open(base_img, 'rb').read())[:soi]
harness = os.path.join(here, 'harness')
ini_path = os.path.join(W, 'neg.ini')
open(ini_path, 'w').write('[ArchiveLimit]\nMaxArchives=1023\n[Harness]\nInstallOnly=1\n')

def run(name, img, extra=(), expect_patch=False, quiet=False):
    p = os.path.join(W, 'neg_%s.bin' % name); open(p, 'wb').write(img)
    d = os.path.join(W, 'neg_%s_dump.bin' % name)
    if os.path.exists(d): os.remove(d)
    r = subprocess.run([harness, ref_img, '0x20000000', p, '0x400000', W, '@' + ini_path, d] + list(extra), capture_output=True, text=True)
    dump = open(d, 'rb').read() if os.path.exists(d) else b''
    n = min(len(dump), len(img))
    unchanged = dump[:n] == bytes(img[:n]) and n > 0
    patched_ok = 'install() returned 1' in r.stdout and '(nothing patched)' not in r.stdout
    log = [l.strip() for l in r.stdout.splitlines() if l.strip() and not l.startswith(('==', 'HULKSMASH 1', 'image base', 'MaxArchives', 'archive index', 'detected', 'install()', '(nothing', '[ArchiveLimit]', '[VehicleBudget]', '[PedBudget]', '--', 'budget ', 'install-only', 'TOTAL'))]
    good = (patched_ok and not unchanged) if expect_patch else (not patched_ok and unchanged)
    if not quiet or not good:
        print('%-18s %s   image %s   %s' % (name, 'accepted' if patched_ok else 'refused ', 'unchanged' if unchanged else 'MODIFIED', (log[0] if log else '')[:100]))
    run.last = (patched_ok, dump, log)
    return good

def mod(f):
    b = bytearray(src); f(b); return b
results = []
results.append(run('hookbyte', mod(lambda b: b.__setitem__(hooks[2] - PREF, b[hooks[2] - PREF] ^ 0x40))))
results.append(run('lasthookbyte', mod(lambda b: b.__setitem__(hooks[-1] - PREF + 1, b[hooks[-1] - PREF + 1] ^ 1))))
results.append(run('relocval', mod(lambda b: struct.pack_into('<I', b, body[5] - PREF, struct.unpack_from('<I', b, body[5] - PREF)[0] + 4))))
results.append(run('bytepatch_orig', mod(lambda b: b.__setitem__(bps[-1][0] - PREF + bps[-1][1], b[bps[-1][0] - PREF + bps[-1][1]] ^ 0x10))))
results.append(run('toolate', mod(lambda b: struct.pack_into('<I', b, table_va + 0x98 - PREF, 0xFFFFFFFF))))
results.append(run('inuse', mod(lambda b: b.__setitem__(table_va + 0x10 - PREF, 0x41))))
results.append(run('timestamp', mod(lambda b: struct.pack_into('<I', b, pe + 8, ts ^ 1))))
results.append(run('sizeofimage', mod(lambda b: struct.pack_into('<I', b, pe + 24 + 56, soi - 0x1000))))
# a hook-site byte beyond the first 8 (the whole hook region is compared)
results.append(run('hookbyte_tail', mod(lambda b: b.__setitem__(hooks[4] - PREF + 4, b[hooks[4] - PREF + 4] ^ 0x80))))
# the unmodified image must be accepted; remember what a good run produces
results.append(run('control_accepts', bytearray(src), expect_patch=True))
good_dump = run.last[1]
npatch = int(re.search(r'\((\d+) patches applied', ' '.join(run.last[2])).group(1))
# forced VirtualProtect failures at every call index. Call #0 seals the stub memory (failure -> nothing is patched).
# After it, calls come in pairs per patch: #1+2k makes the page writable (failure -> everything written so far is rolled
# back, image identical to the original), #2+2k restores the old protection (failure is harmless).
bad = 0
for k in range(0, 1 + 2 * npatch + 3):
    j = k - 1
    want = k > 0 and (j % 2 == 1 or j >= 2 * npatch)
    patched = run('vpfail', bytearray(src), extra=[str(k)], quiet=True, expect_patch=want)
    ok = patched and (run.last[0] and run.last[1] == good_dump) if want else patched
    if not ok: bad += 1; print('  vpfail at call %d: unexpected result' % k)
print('forced VirtualProtect failure at each of %d call indexes: %d unexpected' % (1 + 2 * npatch + 3, bad))
results.append(bad == 0)
print('NEGATIVE TESTS', 'PASSED' if all(results) else 'FAILED')
sys.exit(0 if all(results) else 1)
