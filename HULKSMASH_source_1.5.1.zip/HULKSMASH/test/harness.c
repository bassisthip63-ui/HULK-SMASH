/*
 * Native 32-bit test harness. Maps two flat images of the real GTAIV.exe (1.0.8.0 or 1.2.0.59; the build is picked from the
 * PE timestamp of the image being patched): one stock, one that the plugin patches in place. Then it executes the *actual
 * game code* from both on this machine and compares.
 *
 *   build:  clang --target=i386-linux-gnu -m32 -static -nostdlib -ffreestanding -fno-builtin -fno-pic -no-pie -O1 \
 *           -DWINAPI= -DIMP= -I src test/harness.c -o test/harness
 *   run  :  harness STOCK.bin STOCK_BASE PATCH.bin PATCH_BASE WORKDIR MAXARCHIVES [dump.bin [fail_virtualprotect_call_index]]
 */
#define WINAPI
#define IMP
static unsigned int g_fake_peb;                 /* stands in for fs:[0x30] (the PEB) in the crash-logger tests */
#define GET_PEB() (g_fake_peb)
#include "../src/archive_limit.c"

/* ------------------------------------------------------------------ raw linux syscalls */
static int sc3(int n, int a, int b, int c) { int r; __asm__ volatile("int $0x80" : "=a"(r) : "a"(n), "b"(a), "c"(b), "d"(c) : "memory"); return r; }
static int sys_open(const char *p, int fl, int mode) { return sc3(5, (int)p, fl, mode); }
static int sys_read(int fd, void *b, u32 n)  { return sc3(3, fd, (int)b, (int)n); }
static int sys_write(int fd, const void *b, u32 n) { return sc3(4, fd, (int)b, (int)n); }
static int sys_close(int fd) { return sc3(6, fd, 0, 0); }
static void sys_exit(int c) { sc3(1, c, 0, 0); for (;;); }
static void *sys_mmap(u32 addr, u32 len, int prot, int flags) {
    u32 a[6] = { addr, len, (u32)prot, (u32)flags, (u32)-1, 0 };
    return (void *)sc3(90, (int)a, 0, 0);
}
#define PROT_RWX 7
#define MAP_PRIVATE_ANON_FIXED_NOREPLACE (0x02 | 0x20 | 0x100000)
#define MAP_PRIVATE_ANON 0x22

static u32 slen(const char *s) { u32 n = 0; while (s[n]) n++; return n; }
static void out(const char *s) { sys_write(1, s, slen(s)); }
static void outx(u32 v) { char b[11]; static const char H[] = "0123456789abcdef"; int i; b[0]='0'; b[1]='x'; for (i = 0; i < 8; i++) b[2+i] = H[(v >> (28 - 4*i)) & 15]; b[10]=0; out(b); }
static void outd(u32 v) { char t[12]; int n = 0, i = 0; char o[12]; do { t[n++] = (char)('0' + v % 10); v /= 10; } while (v); while (n) o[i++] = t[--n]; o[i] = 0; out(o); }

static u32 g_fail, g_pass;
static void check(int ok, const char *what, u32 a, u32 b) {
    if (ok) { g_pass++; return; }
    g_fail++;
    if (g_fail < 40) { out("  FAIL: "); out(what); out("  got "); outx(a); out(" expected "); outx(b); out("\n"); }
}

static u32 rng_s = 0x12345679u;
static u32 rnd(void) { rng_s ^= rng_s << 13; rng_s ^= rng_s >> 17; rng_s ^= rng_s << 5; return rng_s; }

/* ------------------------------------------------------------------ Win32 shims (what the plugin imports) */
static const char *g_workdir;
static char g_inipath[300];
static u32 g_img_base;
static int g_mem_next = 0x10000000;

HANDLE GetModuleHandleA(LPCSTR n) { (void)n; return (HANDLE)g_img_base; }
DWORD GetModuleFileNameA(HANDLE h, LPSTR buf, DWORD n) {
    static const char tail[] = "/HULKSMASH.asi"; u32 i, k = 0; (void)h;
    for (i = 0; g_workdir[i] && k + 1 < n; i++) buf[k++] = g_workdir[i];
    for (i = 0; tail[i] && k + 1 < n; i++) buf[k++] = tail[i];
    buf[k] = 0; return k;
}
u32 GetPrivateProfileIntA(LPCSTR sec, LPCSTR key, i32 def, LPCSTR file) {
    /* a small but real INI reader: [Section] headers, Key=Value lines, case-insensitive like the Windows one, ; comments */
    static char buf[4096]; int fd = sys_open(file, 0, 0), n; u32 p = 0, slen_ = slen(sec), klen = slen(key); int in_sec = 0;
    if (fd < 0) return (u32)def;
    n = sys_read(fd, buf, sizeof buf - 1); sys_close(fd); if (n <= 0) return (u32)def; buf[n] = 0;
    while (p < (u32)n) {
        u32 e = p, j; while (e < (u32)n && buf[e] != '\n') e++;
        if (buf[p] == '[') {
            in_sec = 1; for (j = 0; j < slen_; j++) if ((buf[p+1+j] | 32) != (sec[j] | 32)) in_sec = 0;
            if (buf[p+1+slen_] != ']') in_sec = 0;
        } else if (in_sec && buf[p] != ';') {
            int match = 1; for (j = 0; j < klen; j++) if ((buf[p+j] | 32) != (key[j] | 32)) match = 0;
            if (match && buf[p+klen] == '=') { u32 v = 0, q = p + klen + 1; while (buf[q] >= '0' && buf[q] <= '9') v = v*10 + (u32)(buf[q++] - '0'); return v; }
        }
        p = e + 1;
    }
    return (u32)def;
}
/* VirtualAlloc / VirtualProtect honour page protections for memory the plugin allocates, so a stub that runs
   from memory that is not executable faults here, and so does a write to memory that is no longer writable.
   The game image is mapped read/write/execute by the harness and its protection is left alone. */
static u32 win_to_prot(DWORD p) {
    switch (p) { case 0x02: return 1; case 0x04: return 3; case 0x10: return 4; case 0x20: return 5; case 0x40: return 7; }
    return 0;
}
static struct { u32 a, n, p; } g_allocs[64];
static int g_nallocs;
static int g_rwx_allocs;           /* VirtualAlloc calls that asked for writable + executable memory */
LPVOID VirtualAlloc(LPVOID a, u32 n, DWORD t, DWORD p) {
    void *r; (void)a; (void)t;
    if (p == 0x40 || p == 0x80) g_rwx_allocs++;
    n = (n + 0xFFF) & ~0xFFFu;
    r = sys_mmap((u32)g_mem_next, n, (int)win_to_prot(p), MAP_PRIVATE_ANON_FIXED_NOREPLACE);
    g_mem_next += (int)n + 0x10000;
    if ((u32)r > 0xFFFFF000u) return 0;
    if (g_nallocs < 64) { g_allocs[g_nallocs].a = (u32)r; g_allocs[g_nallocs].n = n; g_allocs[g_nallocs].p = p; g_nallocs++; }
    return r;
}
BOOL VirtualFree(LPVOID a, u32 n, DWORD t) { (void)a; (void)n; (void)t; return 1; }
static int g_vp_calls, g_vp_fail_at = -1;
BOOL VirtualProtect(LPVOID a, u32 n, DWORD np, DWORD *op) {
    int i;
    *op = 0x20;
    if (g_vp_calls++ == g_vp_fail_at) return 0;
    for (i = 0; i < g_nallocs; i++)
        if ((u32)a >= g_allocs[i].a && (u32)a + n <= g_allocs[i].a + g_allocs[i].n) {
            u32 lo = (u32)a & ~0xFFFu, hi = ((u32)a + n + 0xFFFu) & ~0xFFFu;
            *op = g_allocs[i].p;
            if (sc3(125, (int)lo, (int)(hi - lo), (int)win_to_prot(np)) != 0) return 0;   /* mprotect */
            g_allocs[i].p = np;
            break;
        }
    return 1;
}
BOOL FlushInstructionCache(HANDLE p, const void *a, u32 n) { (void)p; (void)a; (void)n; return 1; }
HANDLE GetCurrentProcess(void) { return (HANDLE)-1; }
static u32 g_cf_fail;
HANDLE CreateFileA(LPCSTR p, DWORD acc, DWORD sh, void *sa, DWORD cr, DWORD fl, HANDLE t) {
    int fd, flags; (void)sh; (void)sa; (void)fl; (void)t;
    if (g_cf_fail) return INVALID_HANDLE;
    if (cr == 3)      flags = (acc & 0x80000000u) ? 0 : 1;           /* OPEN_EXISTING: no create            */
    else if (cr == 4) flags = 1 | 0x40 | 0x400;                       /* OPEN_ALWAYS:   create, append       */
    else              flags = 1 | 0x40 | 0x200;                       /* CREATE_ALWAYS: create, truncate     */
    fd = sys_open(p, flags, 0644); return fd < 0 ? INVALID_HANDLE : (HANDLE)fd;
}
BOOL WriteFile(HANDLE h, const void *b, DWORD n, DWORD *w, void *o) { int r = sys_write((int)h, b, n); (void)o; if (w) *w = (DWORD)r; return r >= 0; }
BOOL CloseHandle(HANDLE h) { sys_close((int)h); return 1; }
BOOL DisableThreadLibraryCalls(HANDLE h) { (void)h; return 1; }

/* ------------------------------------------------------------------ crash-logger shims and tests */
static u32 g_veh_handler, g_veh_first, g_veh_calls, g_veh_fail, g_tick = 100000;
LPVOID AddVectoredExceptionHandler(u32 first, void *h) { g_veh_calls++; if (g_veh_fail) return 0; g_veh_handler = (u32)h; g_veh_first = first; return (LPVOID)0x77; }
DWORD GetTickCount(void) { return g_tick; }
DWORD GetCurrentThreadId(void) { return 4242; }
void GetLocalTime(void *p) { static const u16 t[8] = { 2026, 10, 3, 21, 22, 9, 56, 123 }; u32 i; for (i = 0; i < 8; i++) ((u16 *)p)[i] = t[i]; }
DWORD GetFileSize(HANDLE h, DWORD *hi) { int r = sc3(19, (int)h, 0, 2); (void)hi; return r < 0 ? 0xFFFFFFFFu : (DWORD)r; }

/* what VirtualQuery says about the test address space: only registered ranges are "committed"; everything else is free */
typedef struct { u32 base, size, prot, type; } VRange;
static VRange g_vr[48]; static u32 g_nvr;
static void vr_add(u32 base, u32 size, u32 prot, u32 type) { g_vr[g_nvr].base = base; g_vr[g_nvr].size = size; g_vr[g_nvr].prot = prot; g_vr[g_nvr].type = type; g_nvr++; }
u32 VirtualQuery(const void *a, void *mbi, u32 len) {
    u32 addr = (u32)a, page = addr & ~0xFFFu, i, nxt = 0xFFFF0000u, sz; u32 *q = (u32 *)mbi; (void)len;
    for (i = 0; i < g_nvr; i++) {
        if (addr >= g_vr[i].base && addr - g_vr[i].base < g_vr[i].size) {
            q[0] = page; q[1] = g_vr[i].base & ~0xFFFu; q[2] = g_vr[i].prot; q[3] = g_vr[i].base + g_vr[i].size - page;
            q[4] = 0x1000; q[5] = g_vr[i].prot; q[6] = g_vr[i].type;
            return 28;
        }
        if (g_vr[i].base > addr && g_vr[i].base < nxt) nxt = g_vr[i].base;
    }
    sz = (nxt & ~0xFFFu) - page; if (sz == 0 || sz > 0x70000000u) sz = 0x1000;
    q[0] = page; q[1] = 0; q[2] = 0; q[3] = sz; q[4] = 0x10000; q[5] = 1; q[6] = 0;
    return 28;
}

#define CL(c, w) check((c) ? 1 : 0, w, 0, 1)
static char g_fb[1 << 21];
static int read_file(const char *path) {
    int fd = sys_open(path, 0, 0), n, tot = 0;
    if (fd < 0) return -1;
    while ((n = sys_read(fd, g_fb + tot, (u32)((int)sizeof g_fb - 1 - tot))) > 0) tot += n;
    sys_close(fd); g_fb[tot] = 0; return tot;
}
static u32 count_in(const char *needle) {
    u32 n = 0, i, k, nl = slen(needle);
    for (i = 0; g_fb[i]; i++) { for (k = 0; k < nl && g_fb[i + k] == needle[k]; k++) { } if (k == nl) n++; }
    return n;
}
static char g_nd[4][600]; static u32 g_ndi;
static char *needle(const char *a, u32 v, const char *b) {            /* a + 8 hex digits + b */
    static const char H[] = "0123456789abcdef";
    char *d = g_nd[g_ndi++ & 3]; u32 n = 0, i; int sh;
    for (i = 0; a[i]; i++) d[n++] = a[i];
    for (sh = 28; sh >= 0; sh -= 4) d[n++] = H[(v >> sh) & 15];
    for (i = 0; b[i]; i++) d[n++] = b[i];
    d[n] = 0; return d;
}
static char *bytes_needle(u32 addr) {                                  /* "bytes at eip: xx xx ..." for 16 bytes at addr */
    static const char H[] = "0123456789abcdef";
    char *d = g_nd[g_ndi++ & 3]; const char *a = "  bytes at eip:"; u32 n = 0, i;
    for (i = 0; a[i]; i++) d[n++] = a[i];
    for (i = 0; i < 16; i++) { u8 b = *(u8 *)(addr + i); d[n++] = ' '; d[n++] = H[b >> 4]; d[n++] = H[b & 15]; }
    d[n] = 0; return d;
}

static char g_logp[300], g_crashp[300];
static u32 g_cx[0xD0 / 4], g_cxsave[0xD0 / 4];
static ExcRec g_er, g_ersave;
static ExcPtrs g_ep;
static u32 g_reg[7];                                                    /* eax ebx ecx edx esi edi ebp for the next call */

static int call_exc(u32 code, u32 eip, u32 esp, u32 acc, u32 addr) {
    u32 i; int r;
    for (i = 0; i < sizeof g_cx / 4; i++) g_cx[i] = 0;
    g_cx[0] = 0x10007u;
    g_cx[CX_EAX] = g_reg[0]; g_cx[CX_EBX] = g_reg[1]; g_cx[CX_ECX] = g_reg[2]; g_cx[CX_EDX] = g_reg[3];
    g_cx[CX_ESI] = g_reg[4]; g_cx[CX_EDI] = g_reg[5]; g_cx[CX_EBP] = g_reg[6];
    g_cx[CX_EIP] = eip; g_cx[CX_ESP] = esp; g_cx[CX_EFL] = 0x10246u;
    { u32 *p = (u32 *)&g_er; for (i = 0; i < sizeof g_er / 4; i++) p[i] = 0; }
    g_er.code = code; g_er.nparams = 2; g_er.info[0] = acc; g_er.info[1] = addr; g_er.addr = eip;
    g_ep.rec = &g_er; g_ep.ctx = g_cx;
    for (i = 0; i < sizeof g_cx / 4; i++) g_cxsave[i] = g_cx[i];
    g_ersave = g_er;
    r = cl_handler(&g_ep);
    for (i = 0; i < sizeof g_cx / 4; i++) if (g_cx[i] != g_cxsave[i]) { check(0, "handler changed the CONTEXT", g_cx[i], g_cxsave[i]); break; }
    { const u32 *a = (const u32 *)&g_er, *b = (const u32 *)&g_ersave; for (i = 0; i < sizeof g_er / 4; i++) if (a[i] != b[i]) { check(0, "handler changed the EXCEPTION_RECORD", a[i], b[i]); break; } }
    return r;
}
static void cl_reset(void) {
    u32 i;
    g_cl_nsites = 0; g_cl_seq = 0; g_cl_banner = 0; g_cl_modprints = 0; g_cl_lastnmods = 0; g_cl_over = 0; g_cl_busy = 0;
    for (i = 0; i < CL_MAXSITES; i++) g_cl_sites[i].count = 0;
    { int fd = sys_open(g_crashp, 1 | 0x40 | 0x200, 0644); if (fd >= 0) sys_close(fd); }
}

/* a fake PEB + loader list: [0] the exe, [1] ntdll.dll, [2] other.asi, then m<i>.dll */
#define FP 0x50020000u
static void put16(u32 a, u32 v) { *(u16 *)a = (u16)v; }
static void put32(u32 a, u32 v) { *(u32 *)a = v; }
static void build_mods(u32 n, u32 exe_base, u32 exe_size) {
    u32 i, k, ldr = FP + 0x100, head = ldr + 0x0c;
    put32(FP + 0x0c, ldr);
    for (i = 0; i < n; i++) {
        u32 e = FP + 0x1000 + i * 0x40, nm = FP + 0x8000 + i * 0x40, nx = (i + 1 < n) ? e + 0x40 : head, base, size;
        char tmp[12]; const char *s = tmp;
        for (k = 0; k < 0x40; k += 4) put32(e + k, 0);
        if (i == 0)      { base = exe_base;   size = exe_size; s = "GTAIV.exe"; }
        else if (i == 1) { base = 0x50040000u; size = 0x8000;  s = "ntdll.dll"; }
        else if (i == 2) { base = 0x50048000u; size = 0x8000;  s = "other.asi"; }
        else { u32 v = i, t = 0; char r[8]; base = 0x60000000u + i * 0x10000u; size = 0x10000;
               tmp[0] = 'm'; do { r[t++] = (char)('0' + v % 10); v /= 10; } while (v); for (k = 0; k < t; k++) tmp[1 + k] = r[t - 1 - k];
               tmp[1 + t] = '.'; tmp[2 + t] = 'd'; tmp[3 + t] = 0; }
        put32(e, nx); put32(e + 4, i ? e - 0x40 : head); put32(e + 0x18, base); put32(e + 0x20, size);
        for (k = 0; s[k]; k++) put16(nm + 2 * k, (u32)s[k]);
        put16(nm + 2 * k, 0);
        put16(e + 0x2c, 2 * k); put16(e + 0x2e, 2 * k + 2); put32(e + 0x30, nm);
    }
    put32(head, n ? FP + 0x1000 : head);
    g_fake_peb = FP;
}
static u32 sum_image(u32 base, u32 size) { u32 s = 0x9E3779B9u, i; for (i = 0; i + 4 <= size; i += 4) s = ((s << 5) | (s >> 27)) ^ *(u32 *)(base + i); return s; }

static void crashlog_tests(u32 P, u32 soi, const char *workdir, const char *build) {
    u32 i, k, sz0, sz1, espv, eip, img_sum0;
    int r;
    static const char t1[] = "/HULKSMASH.log", t2[] = "/HULKSMASH.crash.log";
    for (i = 0, k = 0; workdir[i]; i++) g_logp[k++] = workdir[i];
    for (i = 0; t1[i]; i++) g_logp[k++] = t1[i];
    g_logp[k] = 0;
    for (i = 0, k = 0; workdir[i]; i++) g_crashp[k++] = workdir[i];
    for (i = 0; t2[i]; i++) g_crashp[k++] = t2[i];
    g_crashp[k] = 0;
    out("== crash logger tests ==\n");

    /* ---- registration / switches ---- */
    CL(read_file(g_logp) > 0, "install log was written");
    CL(count_in("HULKSMASH 1.5.1") == 1, "install log: header kept (appending must not truncate)");
    if (!g_cl_on) {
        CL(count_in("[CrashLog]      disabled") == 1, "disabled: log says so");
        CL(g_veh_calls == 0, "disabled: no handler registered");
        CL(count_in("handler installed") == 0, "disabled: no 'installed' line");
        CL(read_file(g_crashp) < 0, "disabled: no crash file created");
        out("  disabled: handler not registered, nothing written\n"); return;
    }
    CL(count_in("[CrashLog]      enabled") == 1, "enabled: log says so");
    if (g_veh_fail) {
        CL(count_in("AddVectoredExceptionHandler failed") == 1, "registration failure is logged");
        CL(g_veh_handler == 0, "registration failure: nothing registered");
        CL(count_in("handler installed") == 0, "registration failure: no 'installed' line");
        out("  registration failure: logged, nothing else affected\n"); return;
    }
    CL(count_in("handler installed") == 1, "'installed' line");
    CL(g_veh_calls == 1 && g_veh_handler == (u32)cl_handler && g_veh_first == 1, "registered once, as the first handler");
    CL(g_cl_main == P, "main module base recorded");

    /* ---- fake address space ---- */
    {
        void *a;
        a = sys_mmap(0x50000000u, 0x1000, 0, MAP_PRIVATE_ANON_FIXED_NOREPLACE);       /* PROT_NONE: a real fault if the handler touches it */
        CL((u32)a == 0x50000000u, "map no-access page");
        a = sys_mmap(0x50010000u, 0x1000, 3, MAP_PRIVATE_ANON_FIXED_NOREPLACE);       /* readable stack page ...                           */
        CL((u32)a == 0x50010000u, "map stack page");
        a = sys_mmap(0x50011000u, 0x1000, 0, MAP_PRIVATE_ANON_FIXED_NOREPLACE);       /* ... followed by a guard page                      */
        CL((u32)a == 0x50011000u, "map guard page");
        a = sys_mmap(FP, 0x10000, 3, MAP_PRIVATE_ANON_FIXED_NOREPLACE);                /* fake PEB / loader list                            */
        CL((u32)a == FP, "map peb page");
        a = sys_mmap(0x50040000u, 0x10000, 3, MAP_PRIVATE_ANON_FIXED_NOREPLACE);       /* "ntdll.dll" and "other.asi"                       */
        CL((u32)a == 0x50040000u, "map module area");
    }
    vr_add(P, soi, 0x40, 0x1000000);
    vr_add(0x50000000u, 0x1000, 0x01, 0x20000);
    vr_add(0x50010000u, 0x1000, 0x04, 0x20000);
    vr_add(0x50011000u, 0x1000, 0x104, 0x20000);
    vr_add(FP, 0x10000, 0x04, 0x20000);
    vr_add(0x50040000u, 0x10000, 0x20, 0x1000000);
    if (g_stub_size) { vr_add(g_stub_base, g_stub_size, 0x40, 0x20000); vr_add(g_tbl_base, g_tbl_size, 0x04, 0x20000); }
    for (i = 0; i < 0x1000 / 4; i++) ((u32 *)0x50010000u)[i] = 0x1000u + i;
    img_sum0 = sum_image(P, soi);

    /* ---- one full record, field by field (a copy of the real crash: esi = 0, the model hash on the stack) ---- */
    cl_reset(); build_mods(3, P, soi);
    eip = P + 0x7192bbu; espv = 0x50010100u;
    ((u32 *)espv)[0] = 0x12345678u; ((u32 *)espv)[4] = P + 0x719b40u; ((u32 *)espv)[9] = 0x50048010u;
    g_reg[0] = 0x11110001u; g_reg[1] = 0x50010020u; g_reg[2] = 0x50048100u; g_reg[3] = 0x44440004u; g_reg[4] = 0; g_reg[5] = 0x66660006u; g_reg[6] = 0x77770007u;
    r = call_exc(0xC0000005u, eip, espv, 0, 0);
    CL(r == 0, "handler returns EXCEPTION_CONTINUE_SEARCH");
    CL(g_cl_busy == 0, "busy flag released");
    CL(read_file(g_crashp) > 0, "crash file written");
    {   /* keep this record next to the logs as a sample of the format */
        char sp[300]; u32 q = 0, w; int fd, len = read_file(g_crashp);
        for (w = 0; workdir[w]; w++) sp[q++] = workdir[w];
        { static const char t3[] = "/sample_record.txt"; for (w = 0; t3[w]; w++) sp[q++] = t3[w]; }
        sp[q] = 0; fd = sys_open(sp, 1 | 0x40 | 0x200, 0644); if (fd >= 0) { sys_write(fd, g_fb, (u32)len); sys_close(fd); }
    }
    CL(count_in("######## game session: HULKSMASH 1.5.1 crash log") == 1, "session banner once");
    CL(count_in(needle("exe: GTAIV.exe at 0x", P, ", ")) == 1, "banner: exe base");
    if (build) { CL(count_in(build) >= 1, "banner: recognised build named"); }
    else CL(count_in("unrecognised build (PE timestamp 0xdeadbeef)") == 1, "banner: unrecognised build says so");
    if (g_stub_size) { CL(count_in(needle(" archives, table at 0x", g_tbl_base, ", stubs at 0x")) == 1 && count_in(needle(", stubs at 0x", g_stub_base, "\r\n")) == 1, "banner: archive table and stub addresses"); }
    else CL(count_in("archive limit: not active") == 1, "banner: archive limit not active");
    CL(count_in("local time 2026-10-21 22:09:56, ") == 1, "local time");
    CL(count_in("thread 4242, exception #1, occurrence 1 at this address") == 1, "thread / sequence / occurrence");
    CL(count_in("code 0xc0000005 ACCESS VIOLATION, read of address 0x00000000") == 1, "exception code and fault address");
    CL(count_in(needle("  eip 0x", eip, " = GTAIV.exe+0x7192bb (exe address as in the unrelocated file: 0x00b192bb)")) == 1, "eip: module + offset + unrelocated address");
    CL(count_in(bytes_needle(eip)) == 1, "bytes at eip are the real code bytes");
    CL(count_in("  esi=00000000 ") == 1, "esi");
    CL(count_in("eax=11110001 ebx=50010020 ecx=50048100 edx=44440004") == 1, "eax..edx");
    CL(count_in("edi=66660006 ebp=77770007 esp=50010100 efl=00010246") == 1, "edi..efl");
    CL(count_in("  esp+0x0: 12345678 ") == 1, "stack dword 0 (the model hash)");
    CL(count_in(needle("  esp+0x10: 0x", P + 0x719b40u, " = GTAIV.exe+0x719b40 (exe address as in the unrelocated file: 0x00b19b40)")) == 1, "return address on the stack is named");
    CL(count_in(needle("  esp+0x24: 0x", 0x50048010u, " = other.asi+0x10")) == 1, "pointer into another module is named");
    CL(count_in("  ecx = 0x50048100 = other.asi+0x100") == 1, "register pointing into a module is named");
    CL(count_in("  [ebx=50010020]:") == 1, "memory behind a readable register is dumped");
    CL(count_in("  [eax=") == 0 && count_in("  [edx=") == 0 && count_in("  [edi=") == 0 && count_in("  [ebp=") == 0, "unreadable registers are not dereferenced");
    CL(count_in("loaded modules (3):") == 1, "module list");
    CL(count_in("  size 0x8000  ntdll.dll") == 1 && count_in("  size 0x8000  other.asi") == 1, "module list names and sizes");
    CL(count_in(needle("  0x", P, "  size 0x")) == 1, "module list: the exe");
    CL(count_in("esp+0x1f0:") == 1 && count_in("esp+0x200:") == 0, "exactly 128 stack dwords (32 lines of 16 bytes)");

    /* ---- exceptions that must be ignored ---- */
    sz0 = (u32)read_file(g_crashp);
    {
        static const u32 ign[] = { 0xE06D7363u, 0x406D1388u, 0xC00000FDu, 0x80000003u, 0x80000001u, 0xC0000008u, 0x40010006u, 0x4000001Fu, 0u };
        for (i = 0; i < sizeof ign / 4; i++) { r = call_exc(ign[i], eip + 4 * i, espv, 0, 0); CL(r == 0, "ignored code returns 0"); }
        r = cl_handler(0); CL(r == 0, "null EXCEPTION_POINTERS");
        g_ep.rec = 0; g_ep.ctx = g_cx; r = cl_handler(&g_ep); CL(r == 0, "null record");
        g_ep.rec = &g_er; g_ep.ctx = 0; r = cl_handler(&g_ep); CL(r == 0, "null context");
    }
    sz1 = (u32)read_file(g_crashp);
    CL(sz0 == sz1, "ignored exception codes write nothing");

    /* ---- repeats: 2 full, then short ones up to 20, one notice, then silence ---- */
    cl_reset(); build_mods(3, P, soi);
    for (k = 0; k < 30; k++) call_exc(0xC0000005u, P + 0x2000u, espv, 1, 0x10);
    read_file(g_crashp);
    CL(count_in("==== local time") == 2, "repeats: 2 full records");
    CL(count_in("-- local time") == 18, "repeats: 18 short records");
    CL(count_in("no further occurrences from this address are logged") == 1, "repeats: one notice");
    CL(count_in("has now happened 21 times") == 1, "repeats: notice counts correctly");
    CL(count_in("occurrence 3 at this address") == 1 && count_in("occurrence 20 at this address") == 1 && count_in("occurrence 21 at this address") == 0, "repeats: occurrence numbers");
    CL(count_in("write to address 0x00000010") == 20, "repeats: write access decoded");
    sz0 = (u32)read_file(g_crashp);
    for (k = 0; k < 200; k++) call_exc(0xC0000005u, P + 0x2000u, espv, 1, 0x10);
    sz1 = (u32)read_file(g_crashp);
    CL(sz0 == sz1, "repeats: nothing more after the notice");
    call_exc(0xC0000094u, P + 0x2000u, espv, 0, 0);                         /* same address, different code = a different site */
    read_file(g_crashp);
    CL(count_in("==== local time") == 3 && count_in("INTEGER DIVIDE BY ZERO") == 1, "same address, other code: logged on its own");

    /* ---- more addresses than the site table holds ---- */
    cl_reset(); build_mods(3, P, soi);
    for (k = 0; k < 64; k++) call_exc(0xC0000005u, P + 0x3000u + 4 * k, espv, 0, 0);
    read_file(g_crashp);
    CL(count_in("==== local time") == 64 && count_in("not tracked on its own") == 0, "64 addresses: all full records");
    for (k = 0; k < 150; k++) call_exc(0xC0000005u, P + 0x4000u + 4 * k, espv, 0, 0);
    read_file(g_crashp);
    CL(count_in("not tracked on its own") == 100 && count_in("==== local time") == 64, "address 65 on: 100 short records, then silence");
    sz0 = (u32)read_file(g_crashp);
    for (k = 0; k < 50; k++) call_exc(0xC0000005u, P + 0x5000u + 4 * k, espv, 0, 0);
    sz1 = (u32)read_file(g_crashp);
    CL(sz0 == sz1, "address table full: file stops growing");
    call_exc(0xC0000005u, P + 0x3000u, espv, 0, 0);                         /* a tracked address still counts */
    read_file(g_crashp);
    CL(count_in("==== local time") == 65, "a tracked address is still logged when the table is full");

    /* ---- memory that cannot be read ---- */
    cl_reset(); build_mods(3, P, soi);
    g_reg[0] = 0x11110001u; g_reg[1] = 0x50000000u; g_reg[2] = 0x50048100u; g_reg[3] = 0x50010FFCu; g_reg[4] = 0x50011000u; g_reg[5] = 0x00000010u; g_reg[6] = 0x50010F00u;
    call_exc(0xC0000005u, eip, 0x50011000u - 40u, 0, 0);                     /* 40 bytes of stack left before a guard page   */
    call_exc(0xC0000005u, eip + 1, 0x50000000u, 0, 0);                       /* esp in a no-access page                       */
    call_exc(0xC0000005u, eip + 2, 0x00000010u, 0, 0);                       /* esp in free memory                            */
    call_exc(0xC0000005u, 0x00020000u, espv, 8, 0x00020000u);                /* eip in free memory (a jump into the void)     */
    call_exc(0xC0000005u, 0x50010000u, espv, 0, 0);                          /* eip in a data page, not in a module           */
    call_exc(0xC0000005u, 0x50011000u, espv, 0, 0);                          /* eip in a guard page                           */
    read_file(g_crashp);
    CL(count_in("esp+0x10: ") >= 1 && count_in("esp+0x20: <memory not readable>") == 1, "stack that runs into a guard page stops cleanly");
    CL(count_in("  esp+0x0: <memory not readable>") == 2, "stack in no-access / free memory: reported, not read");
    CL(count_in("execute (DEP) at address 0x00020000") == 1, "execute fault decoded");
    CL(count_in("(not inside any loaded module; memory region starts at 0x00020000, allocation base 0x00000000, state 0x10000, protect 0x1, type 0x0)") == 1, "eip in free memory described");
    CL(count_in("(not inside any loaded module; memory region starts at 0x50010000, allocation base 0x50010000, state 0x1000, protect 0x4, type 0x20000)") == 1, "eip in a data page described");
    CL(count_in("  bytes at eip: <memory not readable>") == 2, "code bytes behind an unreadable eip (free memory, guard page) are not read");
    CL(count_in("  [ebp=50010f00]:") == 6, "readable register still dumped");
    CL(count_in("  [ebx=") == 0 && count_in("  [esi=") == 0 && count_in("  [edi=") == 0, "no-access / guard / tiny / partly unreadable registers skipped");
    CL(count_in("  [edx=50010ffc]:") == 0, "register 4 bytes before a guard page is not read past the page");

    /* ---- another thread is already logging ---- */
    cl_reset(); build_mods(3, P, soi);
    g_cl_busy = 1; sz0 = (u32)read_file(g_crashp);
    r = call_exc(0xC0000005u, eip, espv, 0, 0);
    sz1 = (u32)read_file(g_crashp);
    CL(r == 0 && sz0 == sz1 && g_cl_busy == 1, "busy: skipped, returns 0, does not release a flag it does not own");
    g_cl_busy = 0;

    /* ---- the log file cannot be opened ---- */
    cl_reset(); build_mods(3, P, soi);
    g_cf_fail = 1; r = call_exc(0xC0000005u, eip, espv, 0, 0); g_cf_fail = 0;
    CL(r == 0 && g_cl_busy == 0 && g_cl_file == INVALID_HANDLE && read_file(g_crashp) == 0, "CreateFile failure: returns 0, nothing written, flag released");
    call_exc(0xC0000005u, eip, espv, 0, 0);
    CL(read_file(g_crashp) > 0, "works again afterwards");

    /* ---- a damaged loader list ---- */
    cl_reset(); build_mods(3, P, soi); put32(FP + 0x1000 + 0x40, FP + 0x1000 + 0x40);          /* entry 1 points at itself */
    call_exc(0xC0000005u, eip, espv, 0, 0); read_file(g_crashp);
    CL(count_in("loaded modules (2):") == 1, "loader list: cycle stops");
    cl_reset(); build_mods(3, P, soi); put32(FP + 0x1000 + 0x40, 0x50000000u);                 /* next pointer into a no-access page */
    call_exc(0xC0000005u, eip, espv, 0, 0); read_file(g_crashp);
    CL(count_in("loaded modules (2):") == 1, "loader list: unreadable next entry stops");
    cl_reset(); build_mods(3, P, soi); put32(FP + 0x1000 + 0x40 + 0x30, 0x50000000u);          /* name buffer unreadable */
    call_exc(0xC0000005u, eip, espv, 0, 0); read_file(g_crashp);
    CL(count_in("loaded modules (3):") == 1 && count_in("  size 0x8000  ?\r\n") == 1, "loader list: unreadable name shown as ?");
    cl_reset(); build_mods(3, P, soi); put16(FP + 0x8000 + 2 * 0x40, 0x4E2D);                  /* non-ASCII character in a name */
    call_exc(0xC0000005u, eip, espv, 0, 0); read_file(g_crashp);
    CL(count_in("  size 0x8000  ?ther.asi") == 1, "loader list: non-ASCII character shown as ?");
    cl_reset(); build_mods(3, P, soi); g_fake_peb = 0;
    call_exc(0xC0000005u, eip, espv, 0, 0); read_file(g_crashp);
    CL(count_in("loaded modules (0):") == 1 && count_in(needle("  eip 0x", eip, "\r\n")) == 1, "no PEB: no modules, eip still logged");
    cl_reset(); build_mods(3, P, soi); g_fake_peb = 0x50000000u;
    call_exc(0xC0000005u, eip, espv, 0, 0); read_file(g_crashp);
    CL(count_in("loaded modules (0):") == 1, "unreadable PEB: no modules");
    cl_reset(); build_mods(300, P, soi);
    call_exc(0xC0000005u, eip, espv, 0, 0); read_file(g_crashp);
    CL(count_in("loaded modules (192):") == 1, "more modules than the table holds: capped");
    cl_reset(); build_mods(3, P, soi);

    /* ---- module list is repeated only when it changed, at most 4 times ---- */
    for (k = 0; k < 6; k++) { build_mods(3 + k, P, soi); call_exc(0xC0000005u, P + 0x6000u + 4 * k, espv, 0, 0); }
    build_mods(9, P, soi); call_exc(0xC0000005u, P + 0x6100u, espv, 0, 0);
    read_file(g_crashp);
    CL(count_in("loaded modules (") == 4, "module list printed at most 4 times");
    cl_reset(); build_mods(3, P, soi);
    call_exc(0xC0000005u, P + 0x6200u, espv, 0, 0); call_exc(0xC0000005u, P + 0x6204u, espv, 0, 0);
    read_file(g_crashp);
    CL(count_in("loaded modules (") == 1, "unchanged module list is not repeated");

    /* ---- this plugin's own memory is named ---- */
    if (g_stub_size) {
        cl_reset(); build_mods(3, P, soi);
        g_reg[2] = g_tbl_base + 0x1e4u;
        call_exc(0xC0000005u, g_stub_base + 0x10u, espv, 0, 0); read_file(g_crashp);
        CL(count_in(needle("  eip 0x", g_stub_base + 0x10u, " = HULKSMASH stub +0x10")) == 1, "eip inside the plugin's stubs is named");
        CL(count_in(" = HULKSMASH archive table +0x1e4") == 1, "register inside the plugin's archive table is named");
        out("  plugin stub/table addresses are named\n");
    } else out("  (archive section not applied in this run: stub naming not tested)\n");

    /* ---- file size cap, applied when the plugin starts ---- */
    cl_reset();
    { int fd = sys_open(g_crashp, 1 | 0x40 | 0x200, 0644); u32 w = 0; for (i = 0; i < sizeof g_fb; i++) g_fb[i] = 'x';
      while (w < 600000) { int m = sys_write(fd, g_fb, 100000); if (m <= 0) break; w += (u32)m; } sys_close(fd); }
    CL(read_file(g_crashp) == 600000, "test file of 600000 bytes");
    crashlog_start();
    CL(read_file(g_crashp) == 0, "a crash log above 512 KB is started afresh");
    { int fd = sys_open(g_crashp, 1 | 0x40 | 0x200, 0644); sys_write(fd, g_fb, 1000); sys_close(fd); }
    crashlog_start();
    CL(read_file(g_crashp) == 1000, "a smaller crash log is kept");
    CL(g_veh_calls >= 3 && g_veh_handler == (u32)cl_handler, "start-up can be repeated");

    /* ---- the handler never touched the game ---- */
    CL(sum_image(P, soi) == img_sum0, "game image byte-for-byte unchanged by all of the above");
    out("  crash logger: done\n");
}

/* ------------------------------------------------------------------ archive usage tests */
static int str_has(const char *hay, const char *nd) {       /* does hay contain nd? (the test map names a build "1.0.8.0", the profile "GTAIV.exe 1.0.8.0") */
    u32 i, k;
    for (i = 0; hay[i]; i++) { for (k = 0; nd[k] && hay[i + k] == nd[k]; k++) { } if (!nd[k]) return 1; }
    return 0;
}
static void usage_fill(u32 v) {
    u32 i;
    for (i = 0; i < g_use_entries; i++) *(u8 *)(g_use_base + i * ENTRY_SIZE + 0x10u) = (i < v) ? 'a' : 0;
}
static char g_ut[4][260];
static char *usage_line(u32 n, u32 seq) {       /* the exact line the report must write for a count of n (seq 0 = game closing) */
    static const char a[] = "[Usage] archives in use: ", b[] = " of ", c[] = " (the game's own table; the ArchiveLimit section is not active)",
                      d[] = " - THE TABLE IS FULL, further archives cannot be registered: raise MaxArchives in HULKSMASH.ini", e[] = " - THE TABLE IS FULL",
                      f[] = " (at crash-log exception #", g[] = " (when the game closed)";
    static u32 sel; char *o = g_ut[sel++ & 3]; u32 q = 0, i; char t[11]; int m;
    for (i = 0; a[i]; i++) o[q++] = a[i];
    m = 0; { u32 v = n; do { t[m++] = (char)('0' + v % 10); v /= 10; } while (v); } while (m) o[q++] = t[--m];
    for (i = 0; b[i]; i++) o[q++] = b[i];
    { u32 v = g_use_entries; do { t[m++] = (char)('0' + v % 10); v /= 10; } while (v); } while (m) o[q++] = t[--m];
    if (seq) { for (i = 0; f[i]; i++) o[q++] = f[i]; { u32 v = seq; do { t[m++] = (char)('0' + v % 10); v /= 10; } while (v); } while (m) o[q++] = t[--m]; o[q++] = ')'; }
    else for (i = 0; g[i]; i++) o[q++] = g[i];
    if (!g_tbl_size) for (i = 0; c[i]; i++) o[q++] = c[i];
    if (n >= g_use_entries) { const char *x = g_tbl_size ? d : e; for (i = 0; x[i]; i++) o[q++] = x[i]; }
    o[q++] = '\r'; o[q++] = '\n'; o[q] = 0; return o;
}
static void usage_reset(void) { g_use_reported = 0; g_use_lines = 0; usage_fill(0); }
#define CK(c, w, a, b) check((c) ? 1 : 0, w, a, b)
static void usage_tests(u32 P, u32 soi, const char *build) {
    const Profile *pf = 0; u32 i, k, expect_base = 0, expect_n = 0, have_report, before;
    out("== archive usage tests ==\n");
    if (build) for (i = 0; i < sizeof g_profiles / sizeof g_profiles[0]; i++) if (str_has(g_profiles[i]->name, build)) pf = g_profiles[i];
    if (g_tbl_size)  { expect_base = g_tbl_base; expect_n = g_arch_entries; }
    else if (pf)     { expect_base = pf->table_va + (P - IMG_PREFBASE); expect_n = STOCK_ENTRIES; }
    have_report = g_use_on && expect_base;

    CL(read_file(g_logp) > 0, "usage: log readable");
    CL(count_in(g_use_on ? "[Usage]         enabled (ReportUsage=1" : "[Usage]         disabled (ReportUsage=0)") == 1, "usage: install log says whether the report is on");
    if (!have_report) {
        before = (u32)read_file(g_logp);
        usage_note(1); usage_closing();
        CK((u32)read_file(g_logp) == before, "usage: nothing written when the report does not apply", (u32)read_file(g_logp), before);
        CK(g_use_base == (g_use_on ? expect_base : (g_tbl_size ? g_tbl_base : 0)), "usage: table known only where it should be", g_use_base, expect_base);
        out("  no usage report in this configuration (ReportUsage off, unsupported exe or similar): checked\n");
        return;
    }
    CK(g_use_base == expect_base && g_use_entries == expect_n, "usage: counts the right table", g_use_base, expect_base);
    read_file(g_logp);
    CL(count_in("[Usage] archives in use") == 0, "usage: nothing is written at start-up");

    /* ---- the counting itself ---- */
    {
        static const u32 ks[] = { 0, 1, 2, 100, 254, 255, 256, 370, 511, 512, 1022, 1023, 2046, 2047 };
        u32 bad = 0;
        for (k = 0; k < sizeof ks / 4; k++) if (ks[k] <= g_use_entries) { usage_fill(ks[k]); if (archives_in_use() != ks[k]) { bad++; check(0, "usage: count", archives_in_use(), ks[k]); } }
        CL(bad == 0, "usage: counts every used entry");
        usage_fill(0); *(u8 *)(g_use_base + 0 * ENTRY_SIZE + 0x10) = 'x'; *(u8 *)(g_use_base + 5 * ENTRY_SIZE + 0x10) = 'y'; *(u8 *)(g_use_base + (g_use_entries - 1) * ENTRY_SIZE + 0x10) = 'z';
        CK(archives_in_use() == 3, "usage: sparse entries are counted wherever they are", archives_in_use(), 3);
        *(u8 *)(g_use_base + 0 * ENTRY_SIZE + 0x0f) = 'q'; *(u8 *)(g_use_base + 1 * ENTRY_SIZE + 0x11) = 'q'; *(u8 *)(g_use_base + 2 * ENTRY_SIZE + 0x98) = 0xFF;
        CK(archives_in_use() == 3, "usage: only the first path byte (+0x10) decides, other fields do not count", archives_in_use(), 3);
        if (g_tbl_size) {
            usage_fill(0); *(u8 *)(g_use_base + g_use_entries * ENTRY_SIZE + 0x10) = 'z';
            CK(archives_in_use() == 0, "usage: the sentinel entry after the table is not counted", archives_in_use(), 0);
            *(u8 *)(g_use_base + g_use_entries * ENTRY_SIZE + 0x10) = 0;
        }
        usage_fill(0);
        *(u8 *)(g_use_base + 0 * ENTRY_SIZE + 0x0f) = 0; *(u8 *)(g_use_base + 1 * ENTRY_SIZE + 0x11) = 0; *(u8 *)(g_use_base + 2 * ENTRY_SIZE + 0x98) = 0;
    }

    /* ---- run 1: still loading, loaded, a crash record with the same count, a late change, then the game closes ---- */
    {
        u32 A = g_use_entries > 372 ? 370 : 200, B2 = A + 2;
        usage_reset();
        read_file(g_logp); before = count_in("[Usage] archives in use");
        usage_note(1);                                                      /* start-up exceptions come before any archive */
        read_file(g_logp);
        CK(count_in("[Usage] archives in use") == before, "usage run 1: a count of 0 is never written", count_in("[Usage] archives in use"), before);
        usage_fill(A); usage_note(5);
        usage_note(6);                                                      /* the same count again */
        usage_fill(B2); usage_closing();
        read_file(g_logp);
        CK(count_in("[Usage] archives in use") == before + 2, "usage run 1: two lines in all", count_in("[Usage] archives in use"), before + 2);
        CL(count_in(usage_line(A, 5)) == 1, "usage run 1: exact text naming the crash-log exception");
        CL(count_in(usage_line(A, 6)) == 0, "usage run 1: an unchanged count is not repeated");
        CL(count_in(usage_line(B2, 0)) == 1, "usage run 1: the changed count when the game closes, exact text");
        CL(count_in("[Usage] no registered archive") == 0, "usage run 1: no 'none seen' line after reporting");
    }
    /* ---- run 2: closing with a count that was already written adds nothing ---- */
    {
        usage_reset();
        usage_fill(150); usage_note(2);
        read_file(g_logp); before = count_in("[Usage] archives in use");
        usage_closing();
        read_file(g_logp);
        CK(count_in("[Usage] archives in use") == before, "usage run 2: closing repeats nothing", count_in("[Usage] archives in use"), before);
    }
    /* ---- run 3: the table fills up completely ---- */
    {
        usage_reset();
        usage_fill(g_use_entries); usage_closing();
        read_file(g_logp);
        CL(count_in(usage_line(g_use_entries, 0)) == 1, "usage run 3: full table is reported once, with the warning");
    }
    /* ---- run 4: no archive ever appears ---- */
    {
        usage_reset();
        read_file(g_logp); before = count_in("[Usage] no registered archive");
        usage_closing();
        read_file(g_logp);
        CL(count_in("[Usage] no registered archive") == before + 1, "usage run 4: 'none seen' reported once, at closing");
        CL(count_in(g_tbl_size ? "[Usage] no registered archive was seen in the plugin's table\r\n" : "(another mod has probably moved it)\r\n") >= 1, "usage run 4: wording matches the table being counted");
    }
    /* ---- run 5: a count that keeps changing: at most 8 lines ---- */
    {
        usage_reset();
        read_file(g_logp); before = count_in("[Usage] archives in use");
        for (k = 0; k < 12; k++) { usage_fill(10 + k); usage_note(k + 1); }
        usage_fill(30); usage_closing();
        read_file(g_logp);
        CK(count_in("[Usage] archives in use") == before + 8, "usage run 5: capped at 8 lines", count_in("[Usage] archives in use"), before + 8);
    }
    /* ---- run 6: a dip to zero and back is not a new report ---- */
    {
        usage_reset();
        read_file(g_logp); before = count_in("[Usage] archives in use");
        usage_fill(150); usage_note(1); usage_fill(0); usage_note(2); usage_fill(150); usage_note(3); usage_closing();
        read_file(g_logp);
        CK(count_in("[Usage] archives in use") == before + 1, "usage run 6: n -> 0 -> n reports n once", count_in("[Usage] archives in use"), before + 1);
    }
    usage_reset();

    /* ---- the number in a crash record ---- */
    if (g_cl_on && !g_veh_fail) {
        u32 eip = P + 0x7192bbu, espv = 0x50010100u, n = g_use_entries < 370 ? g_use_entries : 370;
        char want[220]; u32 q = 0, m, v;
        static const char *suffix[2] = { "\r\n", " (the game's own table; the ArchiveLimit section is not active)\r\n" };
        cl_reset(); build_mods(3, P, soi); usage_reset();
        usage_fill(n);
        read_file(g_logp); before = count_in("[Usage] archives in use");
        call_exc(0xC0000005u, eip, espv, 0, 0);
        read_file(g_logp);
        CK(count_in("[Usage] archives in use") == before + 1 && count_in(usage_line(n, 1)) >= 1, "usage: a full crash record also writes the [Usage] line", count_in("[Usage] archives in use"), before + 1);
        read_file(g_crashp);
        { const char *a = "  archives in use: "; for (m = 0; a[m]; m++) want[q++] = a[m]; }
        { char t[11]; int z = 0; v = n; do { t[z++] = (char)('0' + v % 10); v /= 10; } while (v); while (z) want[q++] = t[--z];
          { const char *b = " of "; for (m = 0; b[m]; m++) want[q++] = b[m]; }
          v = g_use_entries; do { t[z++] = (char)('0' + v % 10); v /= 10; } while (v); while (z) want[q++] = t[--z]; }
        { const char *x = suffix[g_tbl_size ? 0 : 1]; for (m = 0; x[m]; m++) want[q++] = x[m]; }
        want[q] = 0;
        CL(count_in(want) == 1, "usage: the full crash record says how many archives are in use");
        CL(count_in("  archives in use: ") == 1, "usage: ... once per record");
        usage_fill(n + 1 <= g_use_entries ? n + 1 : n);
        call_exc(0xC0000005u, eip + 4, espv, 0, 0);                       /* another address = another full record */
        read_file(g_crashp);
        CL(count_in("  archives in use: ") == 2, "usage: every full record carries the line");
        cl_reset(); build_mods(3, P, soi); usage_reset();
        usage_fill(n);
        for (k = 0; k < 2; k++) call_exc(0xC0000005u, eip + 8, espv, 0, 0);    /* 2 full ... */
        usage_fill(n + 1 <= g_use_entries ? n + 1 : n - 1);
        read_file(g_logp); before = count_in("[Usage] archives in use");
        for (k = 0; k < 2; k++) call_exc(0xC0000005u, eip + 8, espv, 0, 0);    /* ... + 2 short */
        read_file(g_logp);
        CK(count_in("[Usage] archives in use") == before, "usage: a short record writes no [Usage] line", count_in("[Usage] archives in use"), before);
        read_file(g_crashp);
        CL(count_in("  archives in use: ") == 2 && count_in("==== local time") == 2 && count_in("-- local time") == 2, "usage: short records are unchanged (no extra line)");
        usage_reset();
    } else out("  (crash logger off in this run: the crash-record line is not tested)\n");

    /* ---- usage_init does not disturb a table that is already known ---- */
    {
        u32 sb = g_use_base, se = g_use_entries;
        usage_init();
        CL(g_use_base == sb && g_use_entries == se, "usage: usage_init repeated leaves the table settings alone");
    }
    out("  archive usage: done\n");
}

/* ------------------------------------------------------------------ image mapping */
static u32 map_image(const char *path, u32 base, u32 size) {
    void *m = sys_mmap(base, size, PROT_RWX, MAP_PRIVATE_ANON_FIXED_NOREPLACE);
    int fd = sys_open(path, 0, 0); u32 got = 0; int n;
    if ((u32)m != base || fd < 0) { out("cannot map image "); out(path); out("\n"); sys_exit(2); }
    while ((n = sys_read(fd, (u8 *)base + got, size - got)) > 0) got += (u32)n;
    sys_close(fd);
    if (got != size) { out("short image read\n"); sys_exit(2); }
    return base;
}
#define VA(img, va) ((img) + ((va) - IMG_PREFBASE))
#define W32(img, va) (*(u32 *)VA(img, va))

/* ------------------------------------------------------------------ snippet runner */
typedef struct { u32 eax, ebx, ecx, edx, esi, edi, ebp, esp, efl; } Regs;
extern void run_snippet(u32 entry, Regs *in, Regs *outr);
extern void snip_after(void);
u32 snip_after_ptr, snip_entry_v, snip_savesp_v, snip_tmp_v; Regs *snip_in_v, *snip_out_v;

__asm__(
".text\n.globl run_snippet\nrun_snippet:\n"
"  pushl %ebp\n pushl %ebx\n pushl %esi\n pushl %edi\n"
"  movl 20(%esp), %eax\n movl %eax, snip_entry_v\n"
"  movl 24(%esp), %eax\n movl %eax, snip_in_v\n"
"  movl 28(%esp), %eax\n movl %eax, snip_out_v\n"
"  movl %esp, snip_savesp_v\n"
"  movl snip_in_v, %eax\n"
"  movl 28(%eax), %esp\n"
"  pushl 32(%eax)\n popfl\n"
"  movl 4(%eax), %ebx\n movl 8(%eax), %ecx\n movl 12(%eax), %edx\n movl 16(%eax), %esi\n movl 20(%eax), %edi\n movl 24(%eax), %ebp\n"
"  movl 0(%eax), %eax\n"
"  jmp *snip_entry_v\n"
".globl snip_after\nsnip_after:\n"
"  movl %eax, snip_tmp_v\n"
"  movl snip_out_v, %eax\n"
"  movl %ebx, 4(%eax)\n movl %ecx, 8(%eax)\n movl %edx, 12(%eax)\n movl %esi, 16(%eax)\n movl %edi, 20(%eax)\n movl %ebp, 24(%eax)\n"
"  movl %esp, 28(%eax)\n"
"  pushfl\n popl %ebx\n movl %ebx, 32(%eax)\n"
"  movl snip_tmp_v, %ebx\n movl %ebx, 0(%eax)\n"
"  movl snip_savesp_v, %esp\n"
"  popl %edi\n popl %esi\n popl %ebx\n popl %ebp\n ret\n");

/* ------------------------------------------------------------------ the layout-aware test memory */
#define NREC 8
static u8  mem[4096] __attribute__((aligned(16)));
static u32 stk[256]  __attribute__((aligned(16)));          /* fake stack: esp points at stk+64 */
static u32 g_B, g_mask;                                      /* patched layout */
static u32 g_pos[NREC], g_idx[NREC];

static void fill_common(void) { u32 i; for (i = 0; i < sizeof mem; i++) mem[i] = (u8)rnd(); for (i = 0; i < 256; i++) stk[i] = rnd(); }
static void write_fields(int patched) {
    u32 k;
    for (k = 0; k < NREC; k++) {
        u32 v = patched ? ((g_pos[k] << g_B) | g_idx[k]) : ((g_pos[k] << 8) | g_idx[k]);
        *(u32 *)(mem + 24 * k + 4) = v;
    }
}
static void new_records(void) {
    u32 k;
    for (k = 0; k < NREC; k++) { g_pos[k] = rnd() & ((1u << (32 - g_B)) - 1u); g_idx[k] = rnd() % 255u; }
    g_idx[rnd() % NREC] = 0; g_idx[rnd() % NREC] = 254;
}

/* install `jmp *[snip_after_ptr]` at the continuation address so a snippet can stop there */
static void plant_stop(u32 addr) { *(u8 *)addr = 0xFF; *(u8 *)(addr + 1) = 0x25; *(u32 *)(addr + 2) = (u32)&snip_after_ptr; }

static void run_one(u32 entry, Regs *in, Regs *o) {
    in->esp = (u32)(stk + 64);
    run_snippet(entry, in, o);
}

static u32 dec_pos(u32 v, int patched) { return patched ? v >> g_B : v >> 8; }
static u32 dec_idx(u32 v, int patched) { return patched ? v & g_mask : v & 0xFF; }

/* ------------------------------------------------------------------ per-build test map */
enum { K_PLAIN, K_CMP, K_STORE, K_PLACEHOLDER };
typedef struct {
    const char *n; u32 start, cont;
    int basereg, offreg, offmul;     /* address of the record dword = reg[base] + reg[off]*offmul + 4 (offmul 8: off=3k, 1: off=24k, 0: none) */
    u32 live;                        /* bit r set -> compare register r (eax,ebx,ecx,edx,esi,edi,ebp,esp) */
    int kind;
    u32 argslot;                     /* byte offset from esp of the archive-index argument (0 = none) */
    int outreg, outmul;              /* wide-index oracle: register that must end up = idx*outmul (-1 none) */
} Snip;

typedef struct {
    const char *name; u32 timestamp;
    u32 table_ref;                            /* a relocated imm32 that holds the table address ("mov esi, table") */
    u32 table_va;
    u32 setter, gethandle, accessor, recmgr, modtab, init_fn, reg_fn, reg_gate;
    u32 loop_start, loop_stop;                /* optional: a loop bounded by an end pointer (pointer-in-esi walk over entry+0x10 names); 0 = none */
    const Snip *snips; u32 nsnips;
    u32 ped_va, veh_va;                       /* streaming budget variables (stock 50,000,000 / 40,000,000) */
} Cfg;

#define EAX 0
#define EBX 1
#define ECX 2
#define EDX 3
#define ESI 4
#define EDI 5
#define EBP 6
#define ALLREGS 0xFFu

static const Snip S1080[] = {
  { "H3  b6ca19",    0xb6ca19, 0xb6ca1e, ECX, EAX, 8, ALLREGS, K_PLAIN, 0,    EAX, 1 },
  { "H4  b6cb2a",    0xb6cb2a, 0xb6cb32, ESI, -1,  0, ALLREGS, K_CMP,   0x44, EDX, 1 },
  { "H5+H6 b6cb51",  0xb6cb51, 0xb6cb5c, ESI, -1,  0, ALLREGS & ~(1u << ECX), K_STORE, 0x44, -1, 0 },
  { "H7  b6cd3c",    0xb6cd3c, 0xb6cd41, ESI, EDX, 1, ALLREGS, K_PLACEHOLDER, 0, -1, 0 },
  { "H8  b6d08d",    0xb6d08d, 0xb6d094, EAX, -1,  0, ALLREGS, K_PLAIN, 0,    ECX, 5 },
  { "H9  b6d0bc",    0xb6d0bc, 0xb6d0c3, EDX, -1,  0, ALLREGS, K_PLAIN, 0,    EAX, 5 },
  { "H10 b6d11c",    0xb6d11c, 0xb6d121, EDX, EAX, 8, ALLREGS, K_PLAIN, 0,    EAX, 1 },
  { "H11 b6d1bd",    0xb6d1bd, 0xb6d1c4, EAX, -1,  0, ALLREGS, K_PLAIN, 0,    ECX, 5 },
  { "H12 cb1b23",    0xcb1b23, 0xcb1b2b, EDI, -1,  0, ALLREGS, K_PLAIN, 0,    EBP, 5 },
};
static const Snip S1070[] = {
  { "H3  bcc299",    0xbcc299, 0xbcc29e, ECX, EAX, 8, ALLREGS, K_PLAIN, 0,    EAX, 1 },
  { "H4  bcc3aa",    0xbcc3aa, 0xbcc3b2, ESI, -1,  0, ALLREGS, K_CMP,   0x44, EDX, 1 },
  { "H5+H6 bcc3d1",  0xbcc3d1, 0xbcc3dc, ESI, -1,  0, ALLREGS & ~(1u << ECX), K_STORE, 0x44, -1, 0 },
  { "H7  bcc5bc",    0xbcc5bc, 0xbcc5c1, ESI, EDX, 1, ALLREGS, K_PLACEHOLDER, 0, -1, 0 },
  { "H8  bcc90d",    0xbcc90d, 0xbcc914, EAX, -1,  0, ALLREGS, K_PLAIN, 0,    ECX, 5 },
  { "H9  bcc93c",    0xbcc93c, 0xbcc943, EDX, -1,  0, ALLREGS, K_PLAIN, 0,    EAX, 5 },
  { "H10 bcc98c",    0xbcc98c, 0xbcc991, EDX, EAX, 8, ALLREGS, K_PLAIN, 0,    EAX, 1 },
  { "H11 bcca3d",    0xbcca3d, 0xbcca44, EAX, -1,  0, ALLREGS, K_PLAIN, 0,    ECX, 5 },
  { "H12 c572a3",    0xc572a3, 0xc572ab, EDI, -1,  0, ALLREGS, K_PLAIN, 0,    EBP, 5 },
};
static const Snip S1259[] = {
  { "H3  a94b39",    0xa94b39, 0xa94b3e, EAX, EDX, 8, ALLREGS, K_PLAIN, 0,    EAX, 1 },
  { "H4  a9515f",    0xa9515f, 0xa95167, ESI, -1,  0, ALLREGS, K_CMP,   0x48, EAX, 1 },
  { "H6  a9518e",    0xa9518e, 0xa9519b, ESI, -1,  0, ALLREGS & ~(1u << ECX), K_STORE, 0x48, -1, 0 },   /* ecx = a relocated global address, differs by the base delta */
  { "H7  a9501d",    0xa9501d, 0xa95022, EAX, ESI, 1, ALLREGS, K_PLACEHOLDER, 0, -1, 0 },
  { "H8  a94d0d",    0xa94d0d, 0xa94d14, EAX, -1,  0, ALLREGS, K_PLAIN, 0,    EAX, 5 },
  { "H9  a94d3b",    0xa94d3b, 0xa94d42, ESI, -1,  0, ALLREGS, K_PLAIN, 0,    ECX, 5 },
  { "H10 a94f3e",    0xa94f3e, 0xa94f43, EAX, EDX, 8, ALLREGS, K_PLAIN, 0,    EAX, 1 },
  { "H11 a943cd",    0xa943cd, 0xa943d4, EAX, -1,  0, ALLREGS, K_PLAIN, 0,    EDX, 5 },
  { "H12 d5b544",    0xd5b544, 0xd5b54d, EBX, -1,  0, ALLREGS, K_PLAIN, 0,    EAX, 1 },
};
static const Cfg CFGS[] = {
  { "1.0.7.0",  0x4bd9efbeu, 0x421a04, 0x121dfd8, 0xbcbc60, 0xbcbbb0, 0x832cb0, 0xf21c60, 0x1227f98, 0x897700, 0x897730, 0x184a324, 0, 0, S1070, sizeof S1070 / sizeof S1070[0], 0xf22b5c, 0xf22b60 },
  { "1.0.8.0",  0x57c6fb75u, 0x495544, 0x1399800, 0xb6c3e0, 0xb6c330, 0x8b4c40, 0xf493f0, 0x13a37c0, 0xa22bb0, 0xa22be0, 0x17525a0, 0, 0, S1080, sizeof S1080 / sizeof S1080[0], 0xf49b94, 0xf49b98 },
  { "1.2.0.59", 0x63d3e735u, 0x5c2e0e, 0x12fb3b8, 0xa95750, 0xa94300, 0x8d8380, 0x103e8d0, 0x13053a8, 0xa95d50, 0xa95aa0, 0x17ad180, 0xa95e50, 0xa95e82, S1259, sizeof S1259 / sizeof S1259[0], 0x10496d8, 0x10496dc },
};

static void set_reg(Regs *r, int idx, u32 v) { ((u32 *)r)[idx] = v; }
static u32  get_reg(const Regs *r, int idx) { return ((const u32 *)r)[idx]; }

static void setup_regs(const Snip *sn, Regs *r, u32 k) {
    u32 i;
    for (i = 0; i < 7; i++) set_reg(r, (int)i, rnd());
    if (sn->offmul == 0) set_reg(r, sn->basereg, (u32)mem + 24 * k);
    else { set_reg(r, sn->basereg, (u32)mem); set_reg(r, sn->offreg, sn->offmul == 8 ? 3 * k : 24 * k); }
}

static void differential(const Snip *sn, u32 S, u32 P, u32 iters) {
    u32 it, bad = 0;
    static u8  pre_mem[4096], a_mem[4096];
    static u32 pre_stk[256], a_stk[256];
    u32 sA = VA(S, sn->start), sP = VA(P, sn->start);
    for (it = 0; it < iters; it++) {
        Regs in, oa, op; u32 k = rnd() % NREC, i, v;
        new_records(); fill_common();
        setup_regs(sn, &in, k);
        in.efl = 0x2u | (rnd() & 0x8D5u);
        if (sn->argslot) {                         /* the archive index argument on the stack */
            v = (rnd() & 3) ? g_idx[k] : rnd() % 255u;
            stk[64 + sn->argslot / 4] = v;
        }
        for (i = 0; i < 256; i++) pre_stk[i] = stk[i];
        write_fields(0);
        for (i = 0; i < sizeof mem; i++) pre_mem[i] = mem[i];
        run_one(sA, &in, &oa);                      /* stock image, stock record layout */
        for (i = 0; i < sizeof mem; i++) a_mem[i] = mem[i];
        for (i = 0; i < 256; i++) a_stk[i] = stk[i];
        for (i = 0; i < sizeof mem; i++) mem[i] = pre_mem[i];
        write_fields(1);
        for (i = 0; i < 256; i++) stk[i] = pre_stk[i];
        run_one(sP, &in, &op);                      /* patched image, wide record layout */
        {
            u32 r;
            for (r = 0; r < 8; r++) if ((sn->live & (1u << r)) && get_reg(&oa, (int)r) != get_reg(&op, (int)r)) { bad++; check(0, sn->n, get_reg(&op, (int)r), get_reg(&oa, (int)r)); }
            if (sn->kind == K_CMP && ((oa.efl ^ op.efl) & 0x8D5u)) { bad++; check(0, "flags", op.efl & 0x8D5u, oa.efl & 0x8D5u); }
            for (k = 0; k < NREC; k++) {
                u32 fa = *(u32 *)(a_mem + 24 * k + 4), fp = *(u32 *)(mem + 24 * k + 4);
                u32 pa = dec_pos(fa, 0), ia = dec_idx(fa, 0), pp = dec_pos(fp, 1), ip = dec_idx(fp, 1);
                if (sn->kind == K_PLACEHOLDER && ia == 0xFF) ia = g_mask;   /* "no archive" marker is the mask in the new layout */
                if (pa != pp || ia != ip) { bad++; check(0, "record field", fp, fa); }
            }
            for (i = 0; i < sizeof mem; i++) {
                int is_field = (i < 24 * NREC) && (i % 24) >= 4 && (i % 24) < 8;
                if (!is_field && a_mem[i] != mem[i]) { bad++; check(0, "other memory byte", mem[i], a_mem[i]); break; }
            }
            check(oa.esp == op.esp, "final esp", op.esp - (u32)stk, oa.esp - (u32)stk);
            for (i = (oa.esp - (u32)stk) / 4; i < 256; i++) if (a_stk[i] != stk[i]) { bad++; check(0, "live stack", stk[i], a_stk[i]); break; }
            check(1, "", 0, 0);
        }
    }
    out("  "); out(sn->n); out(": "); outd(iters); out(" cases, "); outd(bad); out(" differences\n");
}

/* ------------------------------------------------------------------ main */
static u32 parse_hex(const char *s) { u32 v = 0, i; for (i = 0; s[i]; i++) { char c = s[i]; if (c == 'x' || c == 'X') { v = 0; continue; } v = v * 16 + (u32)(c <= '9' ? c - '0' : (c | 32) - 'a' + 10); } return v; }

int c_main(int argc, char **argv) {
    u32 S, P, sbase, pbase, i, k, T;
    const Cfg *cf = 0;
    int dumpfd;
    if (argc < 7) { out("usage: harness stock.bin sbase patch.bin pbase workdir maxarchives [dump.bin [failat]]\n"); return 2; }
    sbase = parse_hex(argv[2]); pbase = parse_hex(argv[4]);
    /* the profile is chosen from the PE timestamp of the image being patched */
    {
        int fd = sys_open(argv[3], 0, 0); u8 hdr[512]; u32 pe, ts;
        if (fd < 0 || sys_read(fd, hdr, sizeof hdr) != (int)sizeof hdr) { out("cannot read image header\n"); return 2; }
        sys_close(fd);
        pe = *(u32 *)(hdr + 0x3c); ts = *(u32 *)(hdr + pe + 8);
        for (i = 0; i < sizeof CFGS / sizeof CFGS[0]; i++) if (CFGS[i].timestamp == ts) cf = &CFGS[i];
        if (!cf) { out("no test map for this image (timestamp "); outx(ts); out(")\n"); }
    }
    {
        u32 soi = 0; int fd = sys_open(argv[3], 0, 0); u8 hdr[512]; sys_read(fd, hdr, sizeof hdr); sys_close(fd);
        soi = *(u32 *)(hdr + *(u32 *)(hdr + 0x3c) + 24 + 56);
        S = map_image(argv[1], sbase, soi);
        P = map_image(argv[3], pbase, soi);
        g_workdir = argv[5];
        if (argc > 8) { g_vp_fail_at = 0; for (i = 0; argv[8][i]; i++) g_vp_fail_at = g_vp_fail_at * 10 + (argv[8][i] - '0'); }
        {
            int fd2; u32 n = 0; const char *t = "/HULKSMASH.ini", *h = "[ArchiveLimit]\nMaxArchives=";
            for (i = 0; g_workdir[i]; i++) g_inipath[n++] = g_workdir[i];
            for (i = 0; t[i]; i++) g_inipath[n++] = t[i]; g_inipath[n] = 0;
            fd2 = sys_open(g_inipath, 0x241, 0644);
            if (argv[6][0] == '@') {                 /* take the ini text from a file */
                static char tmp[4096]; int fd3 = sys_open(argv[6] + 1, 0, 0), m;
                if (fd3 < 0) { out("cannot read ini file\n"); return 2; }
                m = sys_read(fd3, tmp, sizeof tmp); sys_close(fd3); if (m > 0) sys_write(fd2, tmp, (u32)m);
            } else {
                sys_write(fd2, h, slen(h)); sys_write(fd2, argv[6], slen(argv[6])); sys_write(fd2, "\n", 1);
            }
            sys_close(fd2);
        }
        snip_after_ptr = (u32)snip_after;

        out("== install() on the mapped copy ==\n");
        g_img_base = P;
        g_loglen = 0;
        {
            int ok;
            u32 pre_veh = 0, pre_ped = 0;
            if (cf) { pre_veh = W32(P, cf->veh_va); pre_ped = W32(P, cf->ped_va); }
            ok = install((HANDLE)0);
            sys_write(1, g_log, g_loglen);
            out(ok ? "install() returned 1\n" : "install() returned 0\n");
            out("rwx allocations: "); outd((u32)g_rwx_allocs); out("\n");
            if (argc > 7) { dumpfd = sys_open(argv[7], 0x241, 0644); sys_write(dumpfd, (void *)P, soi); sys_close(dumpfd); }
            if (cf) {                                /* budget sections: what the ini asked for vs what is in the image now */
                u32 post_veh = W32(P, cf->veh_va), post_ped = W32(P, cf->ped_va), w;
                for (w = 0; w < 2; w++) {
                    const char *sec = w ? "PedBudget" : "VehicleBudget";
                    u32 pre = w ? pre_ped : pre_veh, post = w ? post_ped : post_veh, stock = w ? 50000000u : 40000000u;
                    u32 en = GetPrivateProfileIntA(sec, "Enabled", 0, g_inipath), val = GetPrivateProfileIntA(sec, "Value", w ? 75000000 : 120000000, g_inipath);
                    u32 ow = GetPrivateProfileIntA(sec, "Overwrite", 0, g_inipath), expect = pre;
                    if (en && val >= 1000000u && val <= 0x7FFFFFFFu && pre != val && (pre == stock || ow)) expect = val;
                    out("budget "); out(w ? "ped" : "veh"); out(": before "); outd(pre); out(" after "); outd(post); out(" expected "); outd(expect); out("\n");
                    if (!GetPrivateProfileIntA("Harness", "SkipBudgetCheck", 0, g_inipath)) check(post == expect, "budget variable", post, expect);
                }
            }
            if (GetPrivateProfileIntA("Harness", "CrashLogTest", 0, g_inipath)) {          /* the same order as DllMain: install, log, crash logger */
                g_veh_fail = GetPrivateProfileIntA("Harness", "VehFail", 0, g_inipath);
                flush_log(); crashlog_start(); usage_init();
                crashlog_tests(P, soi, g_workdir, cf ? cf->name : 0);
                usage_tests(P, soi, cf ? cf->name : 0);
                out("\nTOTAL: pass="); outd(g_pass); out(" fail="); outd(g_fail); out("\n");
                return g_fail ? 1 : 0;
            }
            if (GetPrivateProfileIntA("Harness", "InstallOnly", 0, g_inipath)) {      /* tests that only care what install() did */
                out("install-only run\n"); out("\nTOTAL: pass="); outd(g_pass); out(" fail="); outd(g_fail); out("\n");
                return (ok ? 0 : 1) | (g_fail ? 1 : 0);
            }
            if (!ok || g_nundo == 0) { out("(nothing patched)\n"); out("\nTOTAL: pass="); outd(g_pass); out(" fail="); outd(g_fail); out("\n"); return (ok ? 0 : 1) | (g_fail ? 1 : 0); }
        }
    }
    if (!cf) return 1;
    /* was the archive section applied? (the imm32 of "mov esi, table" moved to a new table) */
    if (W32(P, cf->table_ref) == W32(S, cf->table_ref) + (pbase - sbase)) {
        out("archive section not applied: skipping the archive tests\n");
        out("\nTOTAL: pass="); outd(g_pass); out(" fail="); outd(g_fail); out("\n");
        return g_fail ? 1 : 0;
    }
    out("test map: "); out(cf->name); out("\n");
    T = *(u32 *)VA(P, cf->table_ref);               /* the imm32 of "mov esi, table" now holds the new table address */
    out("new table at "); outx(T); out("\n");
    {
        u32 maxa = GetPrivateProfileIntA("ArchiveLimit", "MaxArchives", 1023, g_inipath);
        if (maxa > MAX_ARCHIVES_CAP) maxa = MAX_ARCHIVES_CAP;
        g_B = 8; while (((1u << g_B) - 1u) < maxa) g_B++;
        g_mask = (1u << g_B) - 1u;
    }
    out("B = "); outd(g_B); out(", mask = "); outx(g_mask); out("\n");

    /* ---------------- T1: record setter ---------------- */
    out("== whole-function tests ==\n");
    for (k = 0; k < 20000; k++) {
        u8 recS[32] __attribute__((aligned(16))), recP[32] __attribute__((aligned(16)));
        u32 pos = rnd() & ((1u << (32 - g_B)) - 1u), size = rnd() & 0x3FFFFFFFu, idx = rnd() % 255u, fl = rnd() & 3u, junk = rnd();
        void (__attribute__((thiscall)) *fS)(void *, u32, u32) = (void *)VA(S, cf->setter);
        void (__attribute__((thiscall)) *fP)(void *, u32, u32) = (void *)VA(P, cf->setter);
        for (i = 0; i < 32; i++) recS[i] = recP[i] = (u8)(junk >> (i & 15));
        *(u32 *)(recS + 4) = idx;           *(u32 *)(recP + 4) = idx;
        *(u32 *)(recS + 8) = fl | 0x3000;   *(u32 *)(recP + 8) = fl | 0x3000;
        fS(recS, pos, size); fP(recP, pos, size);
        check(*(u32 *)(recS + 4) == ((pos << 8) | idx), "stock setter layout", *(u32 *)(recS + 4), (pos << 8) | idx);
        check(*(u32 *)(recP + 4) == ((pos << g_B) | idx), "patched setter layout", *(u32 *)(recP + 4), (pos << g_B) | idx);
        check(*(u32 *)(recS + 8) == *(u32 *)(recP + 8), "setter size/flags dword", *(u32 *)(recP + 8), *(u32 *)(recS + 8));
        check(*(u32 *)(recS + 8) == ((size << 2) | fl), "setter size field", *(u32 *)(recS + 8), (size << 2) | fl);
        for (i = 0; i < 32; i++) if (i < 4 || i >= 12) check(recS[i] == recP[i], "setter untouched bytes", recP[i], recS[i]);
    }
    for (k = 0; k < 20000; k++) {            /* idx above 255 on the patched layout (cannot exist in stock) */
        u8 recP[32] __attribute__((aligned(16)));
        u32 pos = rnd() & ((1u << (32 - g_B)) - 1u), idx = rnd() % (g_mask + 1);
        void (__attribute__((thiscall)) *fP)(void *, u32, u32) = (void *)VA(P, cf->setter);
        *(u32 *)(recP + 4) = idx; *(u32 *)(recP + 8) = 1; fP(recP, pos, 0x1234);
        check(*(u32 *)(recP + 4) == ((pos << g_B) | idx), "patched setter, wide idx", *(u32 *)(recP + 4), (pos << g_B) | idx);
    }
    out("  setter done\n");

    /* ---------------- T2: GetHandle ---------------- */
    for (k = 0; k < 20000; k++) {
        u8 recS[32] __attribute__((aligned(16))), recP[32] __attribute__((aligned(16)));
        u32 pos = rnd() & ((1u << (32 - g_B)) - 1u), idx = rnd() % 255u, wide = rnd() % g_mask;
        u32 (__attribute__((thiscall)) *gS)(void *) = (void *)VA(S, cf->gethandle);
        u32 (__attribute__((thiscall)) *gP)(void *) = (void *)VA(P, cf->gethandle);
        u32 rS, rP;
        for (i = 0; i < 32; i++) recS[i] = recP[i] = 0;
        *(u32 *)(recS + 4) = (pos << 8) | idx;        *(u32 *)(recP + 4) = (pos << g_B) | idx;
        *(u32 *)(recS + 8) = 0x400;                   *(u32 *)(recP + 8) = 0x400;
        *(u32 *)VA(S, cf->table_va + 0x94 + idx * 0xA0) = idx << 24;
        *(u32 *)(T + idx * 0xA0 + 0x94) = idx << (32 - g_B);
        rS = gS(recS); rP = gP(recP);
        check(rS == pos + (idx << 24), "stock GetHandle", rS, pos + (idx << 24));
        check(rP == pos + (idx << (32 - g_B)), "patched GetHandle", rP, pos + (idx << (32 - g_B)));
        *(u32 *)(recP + 4) = (pos << g_B) | wide;
        *(u32 *)(T + wide * 0xA0 + 0x94) = wide << (32 - g_B);
        rP = gP(recP);
        check(rP == pos + (wide << (32 - g_B)), "patched GetHandle, wide idx", rP, pos + (wide << (32 - g_B)));
        check((rP >> (32 - g_B)) == wide, "handle top bits identify the archive", rP >> (32 - g_B), wide);
        check((rP & ((1u << (32 - g_B)) - 1u)) == pos, "handle low bits are the block position", rP & ((1u << (32 - g_B)) - 1u), pos);
    }
    out("  GetHandle done\n");

    /* ---------------- T3: GetArchiveIdx accessor ---------------- */
    {
        static u8 recs[24 * 64] __attribute__((aligned(16)));
        for (k = 0; k < 20000; k++) {
            u32 id = rnd() % 20, module = rnd() % 4, base = rnd() % 20, idx = rnd() % (g_mask + 1), pos = rnd() & ((1u << (32 - g_B)) - 1u);
            u32 (*aP)(u32, u32) = (void *)VA(P, cf->accessor);
            u32 (*aS)(u32, u32) = (void *)VA(S, cf->accessor);
            W32(P, cf->recmgr) = (u32)recs; W32(S, cf->recmgr) = (u32)recs;
            *(u32 *)VA(P, cf->modtab + module * 0x64) = base; *(u32 *)VA(S, cf->modtab + module * 0x64) = base;
            *(u32 *)(recs + 24 * (base + id) + 4) = (pos << g_B) | idx;
            check(aP(id, module) == idx, "accessor (patched layout, wide idx)", aP(id, module), idx);
            if (idx < 255) {
                *(u32 *)(recs + 24 * (base + id) + 4) = (pos << 8) | idx;
                check(aS(id, module) == idx, "accessor (stock)", aS(id, module), idx);
            }
        }
    }
    out("  accessor done\n");

    /* ---------------- T4: table init: runs the real loop with the patched end pointer ---------------- */
    {
        u32 nent = g_mask, j; void (*initP)(void) = (void *)VA(P, cf->init_fn);
        u8 *oldp = (u8 *)VA(P, cf->table_va); u8 *tailp = (u8 *)VA(P, cf->table_va + 255 * 0xA0);
        u8 guard[0x400];
        for (j = 0; j < sizeof guard; j++) guard[j] = tailp[j];
        for (j = 0; j < (nent + 1) * 0xA0; j++) ((u8 *)T)[j] = 0;
        initP();
        { u32 bad = 0;
          for (j = 0; j < nent; j++) { if (*(u32 *)(T + j * 0xA0 + 0x98) != 0xFFFFFFFFu) bad++; if (*(u8 *)(T + j * 0xA0 + 0x10) != 0) bad++; }
          check(bad == 0, "init: every usable entry initialised", bad, 0);
          bad = 0; for (j = 0; j < 0xA0; j++) if (((u8 *)T)[nent * 0xA0 + j] != 0) bad++;
          check(bad == 0, "init: sentinel entry left alone", bad, 0);
          bad = 0; for (j = 0; j < 255 * 0xA0; j++) if (oldp[j] != 0) bad++;
          check(bad == 0, "init: old static table untouched", bad, 0);
          bad = 0; for (j = 0; j < sizeof guard; j++) if (tailp[j] != guard[j]) bad++;
          check(bad == 0, "init: data after the old table untouched", bad, 0);
        }
        out("  init done\n");
    }

    /* ---------------- T5: registration with a full table returns 0 ---------------- */
    {
        u32 nent = g_mask, j; u32 (*regP)(u32, u32, u32) = (void *)VA(P, cf->reg_fn);
        W32(P, cf->reg_gate) = 0;
        for (j = 0; j < nent; j++) *(u8 *)(T + j * 0xA0 + 0x10) = 'x';
        check(regP(0, 0, 0xFFFFFFFFu) == 0, "register: table full -> 0", regP(0, 0, 0xFFFFFFFFu), 0);
        out("  registration-full done\n");
    }

    /* ---------------- T5b: a loop that walks the entries by pointer and stops at the table end pointer ---------------- */
    if (cf->loop_start) {
        static const u32 ks[] = { 1, 2, 100, 254, 255, 256, 300, 510, 511, 512, 1000, 1022, 1023, 2046, 2047 };
        u32 n, nent = g_mask, bad = 0, tests = 0;
        plant_stop(VA(S, cf->loop_stop)); plant_stop(VA(P, cf->loop_stop));
        out("== end-pointer loop test ==\n");
        for (n = 0; n < sizeof ks / sizeof ks[0]; n++) {
            u32 K = ks[n], j; Regs in, o;
            if (K > nent) continue;
            if (K <= 255) {                                   /* stock image: K named entries, then an empty one */
                for (j = 0; j < 255 * 0xA0; j++) *(u8 *)VA(S, cf->table_va + j) = 0;
                for (j = 0; j < K; j++) *(u8 *)VA(S, cf->table_va + j * 0xA0 + 0x10) = 'a';
                in.eax = in.ebx = in.ecx = in.edx = in.esi = in.ebp = 0x11111111u; in.edi = 0; in.efl = 2; run_one(VA(S, cf->loop_start), &in, &o);
                tests++; if (o.edi != K) { bad++; check(0, "stock loop count", o.edi, K); }
            }
            for (j = 0; j < (nent + 1) * 0xA0; j++) *(u8 *)(T + j) = 0;   /* patched image: K named entries, entry K and the sentinel are empty */
            for (j = 0; j < K; j++) *(u8 *)(T + j * 0xA0 + 0x10) = 'a';
            in.eax = in.ebx = in.ecx = in.edx = in.esi = in.ebp = 0x22222222u; in.edi = 0; in.efl = 2; run_one(VA(P, cf->loop_start), &in, &o);
            tests++; if (o.edi != K) { bad++; check(0, "patched loop count", o.edi, K); }
            if (K == nent) { /* all usable entries named: only the end pointer can stop the walk (entry N is the zero sentinel here, so also name it to prove the bound) */
                *(u8 *)(T + nent * 0xA0 + 0x10) = 'z';
                in.edi = 0; in.efl = 2; run_one(VA(P, cf->loop_start), &in, &o);
                tests++; if (o.edi != nent) { bad++; check(0, "patched loop stops at the end pointer", o.edi, nent); }
            }
        }
        check(bad == 0, "end-pointer loop", bad, 0);
        out("  "); outd(tests); out(" loop runs, "); outd(bad); out(" wrong\n");
    }

    /* ---------------- T6: snippet differential tests for the in-function hooks ---------------- */
    out("== snippet differential tests (real game code, stock vs patched) ==\n");
    for (i = 0; i < cf->nsnips; i++) {
        plant_stop(VA(S, cf->snips[i].cont)); plant_stop(VA(P, cf->snips[i].cont));
        differential(&cf->snips[i], S, P, 20000);
    }

    /* ---------------- T7: oracle tests for archive indexes the stock layout cannot represent ---------------- */
    out("== oracle tests for wide indexes (patched image only) ==\n");
    {
        u32 bad = 0, n;
        for (n = 0; n < cf->nsnips; n++) {
            const Snip *sn = &cf->snips[n]; u32 sbad = 0;
            for (k = 0; k < 20000; k++) {
                Regs in, o; u32 r = rnd() % NREC;
                u32 pos = rnd() & ((1u << (32 - g_B)) - 1u), idx = rnd() % (g_mask + 1);
                new_records(); fill_common(); g_idx[r] = idx; g_pos[r] = pos; write_fields(1);
                setup_regs(sn, &in, r); in.efl = 0x2u | (rnd() & 0x8D5u);
                if (sn->argslot) stk[64 + sn->argslot / 4] = idx;
                run_one(VA(P, sn->start), &in, &o);
                switch (sn->kind) {
                case K_PLAIN:
                    if (get_reg(&o, sn->outreg) != idx * (u32)sn->outmul) { sbad++; check(0, sn->n, get_reg(&o, sn->outreg), idx * (u32)sn->outmul); }
                    break;
                case K_CMP:
                    if (get_reg(&o, sn->outreg) != idx || !(o.efl & 0x40)) { sbad++; check(0, "wide cmp (reg / ZF)", get_reg(&o, sn->outreg), idx); }
                    stk[64 + sn->argslot / 4] = idx ^ 1; setup_regs(sn, &in, r); in.efl = 0x2u; run_one(VA(P, sn->start), &in, &o);
                    if (o.efl & 0x40) { sbad++; check(0, "wide cmp: ZF set for unequal", 1, 0); }
                    break;
                case K_STORE: {
                    u32 f = *(u32 *)(mem + 24 * r + 4);
                    if ((f & g_mask) != idx || (f >> g_B) != pos) { sbad++; check(0, "wide store", f, (pos << g_B) | idx); }
                    break; }
                case K_PLACEHOLDER: {
                    u32 f = *(u32 *)(mem + 24 * r + 4);
                    if ((f & g_mask) != g_mask || (f >> g_B) != pos) { sbad++; check(0, "placeholder marker", f, (pos << g_B) | g_mask); }
                    break; }
                }
            }
            out("  "); out(sn->n); out(": "); outd(sbad); out(" differences\n");
            bad += sbad;
        }
        out("  wide-index oracle total: "); outd(bad); out(" differences\n");
    }

    out("\nTOTAL: pass="); outd(g_pass); out(" fail="); outd(g_fail); out("\n");
    return g_fail ? 1 : 0;
}

__asm__(".text\n.globl _start\n_start:\n  xorl %ebp, %ebp\n  movl %esp, %eax\n  andl $-16, %esp\n  subl $12, %esp\n  pushl %eax\n  call start_c\n");
void start_c(u32 *sp) { int argc = (int)sp[0]; char **argv = (char **)(sp + 1); sys_exit(c_main(argc, argv)); }
