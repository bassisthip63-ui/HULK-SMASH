#!/usr/bin/env python3
"""pe_checksum.py FILE : writes the standard PE image checksum (the one imagehlp's CheckSumMappedFile computes)."""
import struct, sys
p = sys.argv[1]
d = bytearray(open(p, 'rb').read())
off = struct.unpack_from('<I', d, 0x3C)[0] + 24 + 64      # OptionalHeader.CheckSum
struct.pack_into('<I', d, off, 0)
s = 0
data = d + (b'\0' if len(d) & 1 else b'')
for (w,) in struct.iter_unpack('<H', data):
    s += w
    s = (s & 0xFFFF) + (s >> 16)
s = (s & 0xFFFF) + (s >> 16)
s = (s + len(d)) & 0xFFFFFFFF
struct.pack_into('<I', d, off, s)
open(p, 'wb').write(d)
print('PE checksum %08X' % s)
