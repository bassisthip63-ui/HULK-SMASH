/*
 * HULKSMASH.asi  -  streaming limit adjuster for GTA IV (GTAIV.exe 1.0.7.0, 1.0.8.0, 1.2.0.59)
 *
 * Independent sections, each with its own switch in HULKSMASH.ini:
 *
 *   [ArchiveLimit]   raises the 255 .img archive limit
 *       What the game does (reverse engineered from the exes):
 *         - archives live in a static table of 255 entries, 0xA0 bytes each
 *         - every streaming record (24 bytes) keeps "block position << 8 | archive index" in a dword at +4,
 *           so the archive index is limited to 8 bits
 *         - a streaming handle is  position + (archive index << 24)
 *       What this section does, only when MaxArchives is above 255:
 *         - moves the table into freshly allocated memory (size = 2^B entries, B = 9, 10 or 11)
 *         - widens the archive-index field of the record dword from 8 to B bits (position keeps 32-B bits)
 *         - widens the handle base shift from 24 to 32-B
 *
 *   [VehicleBudget]  the streaming memory the game allows for vehicle models (stock 40,000,000 bytes: "taxi bug")
 *   [PedBudget]      the same for pedestrian models (stock 50,000,000 bytes)
 *       Both are plain 32-bit variables in .data; the section writes the configured value.
 *
 *   [CrashLog]       a diagnostic aid, not a patch: registers a vectored exception handler that only READS and WRITES A LOG
 *       (HULKSMASH.crash.log) when the game raises an access violation or a similar serious exception: exception code,
 *       address (module + offset), registers, stack, the modules loaded. It never handles, changes or hides an exception
 *       (it always returns EXCEPTION_CONTINUE_SEARCH), so the game crashes exactly as it would without it.
 *
 *   ReportUsage      (key in [ArchiveLimit], on by default) a diagnostic, not a patch: no thread of its own (1.4 had one; an
 *       extra thread in the game process went with heap corruption in TBoGT). It only READS the archive table and writes
 *       "[Usage] archives in use: N of M" to HULKSMASH.log when the crash logger writes a full record and when the game
 *       closes; full crash-log records show the same number.
 *
 * Every byte a section is going to change is verified first. If anything does not match (wrong exe, another mod
 * already patched the spot, plugin loaded too late) that section changes nothing; the other sections are unaffected.
 */

typedef unsigned char  u8;
typedef unsigned short u16;
typedef unsigned int   u32;
typedef int            i32;
typedef void          *HANDLE;
typedef u32            DWORD;
typedef int            BOOL;
typedef const char    *LPCSTR;
typedef char          *LPSTR;
typedef void          *LPVOID;

#ifndef WINAPI
#define WINAPI __stdcall
#endif
#ifndef IMP
#define IMP    __declspec(dllimport)
#endif

IMP HANDLE WINAPI GetModuleHandleA(LPCSTR);
IMP DWORD  WINAPI GetModuleFileNameA(HANDLE, LPSTR, DWORD);
IMP u32    WINAPI GetPrivateProfileIntA(LPCSTR, LPCSTR, i32, LPCSTR);
IMP LPVOID WINAPI VirtualAlloc(LPVOID, u32, DWORD, DWORD);
IMP BOOL   WINAPI VirtualFree(LPVOID, u32, DWORD);
IMP BOOL   WINAPI VirtualProtect(LPVOID, u32, DWORD, DWORD *);
IMP BOOL   WINAPI FlushInstructionCache(HANDLE, const void *, u32);
IMP HANDLE WINAPI GetCurrentProcess(void);
IMP HANDLE WINAPI CreateFileA(LPCSTR, DWORD, DWORD, void *, DWORD, DWORD, HANDLE);
IMP BOOL   WINAPI WriteFile(HANDLE, const void *, DWORD, DWORD *, void *);
IMP BOOL   WINAPI CloseHandle(HANDLE);
IMP BOOL   WINAPI DisableThreadLibraryCalls(HANDLE);
/* crash logger only */
IMP LPVOID WINAPI AddVectoredExceptionHandler(u32, void *);
IMP u32    WINAPI VirtualQuery(const void *, void *, u32);
IMP DWORD  WINAPI GetTickCount(void);
IMP DWORD  WINAPI GetCurrentThreadId(void);
IMP void   WINAPI GetLocalTime(void *);
IMP DWORD  WINAPI GetFileSize(HANDLE, DWORD *);

#define MEM_COMMIT_RESERVE   0x3000u
#define MEM_RELEASE          0x8000u
#define PAGE_READWRITE       0x04u
#define PAGE_EXECUTE_READ    0x20u
#define PAGE_EXECUTE_RW      0x40u
#define INVALID_HANDLE       ((HANDLE)(i32)-1)

#include "profiles_gen.h"  /* RefSite, Fix, StubDef, HookDef, BytePatch, Profile, g_profiles[] */

/* ---- layout constants shared by every supported build ------------------------------------------ */
#define STOCK_ENTRIES      255u
#define ENTRY_SIZE         0xA0u
#define IMG_PREFBASE       0x00400000u
#define MAX_ARCHIVES_CAP   2047u

/* ---- tiny runtime ------------------------------------------------------------------------- */
static void mcopy(void *d, const void *s, u32 n) { __asm__ volatile("rep movsb" : "+D"(d), "+S"(s), "+c"(n) : : "memory"); }
static u32  rd32(const void *p) { u32 v; __builtin_memcpy(&v, p, 4); return v; }
static void wr32l(void *p, u32 v) { __builtin_memcpy(p, &v, 4); }

static char g_log[6144];
static u32  g_loglen;
static void Ls(const char *s) { while (*s && g_loglen < sizeof g_log - 1) g_log[g_loglen++] = *s++; }
static void Lx(u32 v) {
    static const char H[] = "0123456789abcdef";
    char t[10]; int n = 0;
    Ls("0x");
    do { t[n++] = H[v & 15]; v >>= 4; } while (v);
    while (n) { if (g_loglen < sizeof g_log - 1) g_log[g_loglen++] = t[--n]; }
}
static void Ld(u32 v) {
    char t[11]; int n = 0;
    do { t[n++] = (char)('0' + v % 10); v /= 10; } while (v);
    while (n) { if (g_loglen < sizeof g_log - 1) g_log[g_loglen++] = t[--n]; }
}

static char g_base_path[272];       /* module path without extension */

/* memory the archive section allocated (only set once that section succeeded); the crash logger names addresses inside it */
static u32 g_stub_base, g_stub_size, g_tbl_base, g_tbl_size, g_arch_entries;

/* the archive table whose entries are counted (the plugin's table, or the game's own 255-entry one) and how many it has;
 * g_use_base == 0: unknown. An entry is "in use" when the first byte of its path (entry +0x10) is not 0 - the same test the
 * game itself uses to find a free slot when it registers an archive. */
static u32 g_use_on = 1, g_use_base, g_use_entries;
static u32 archives_in_use(void) {
    u32 i, n = 0;
    if (!g_use_base) return 0;
    for (i = 0; i < g_use_entries; i++) if (*(const volatile u8 *)(g_use_base + i * ENTRY_SIZE + 0x10u)) n++;
    return n;
}

/* ---- guarded writes with undo -------------------------------------------------------------- */
typedef struct { u32 addr; u32 n; u8 old[40]; } Undo;
static Undo g_undo[160];
static u32  g_nundo;

static int patch_write(u32 addr, const void *src, u32 n) {
    DWORD oldprot, tmp;
    Undo *u;
    if (n > sizeof g_undo[0].old || g_nundo >= sizeof g_undo / sizeof g_undo[0]) return 0;
    if (!VirtualProtect((void *)addr, n, PAGE_EXECUTE_RW, &oldprot)) return 0;
    u = &g_undo[g_nundo++];
    u->addr = addr; u->n = n;
    mcopy(u->old, (void *)addr, n);
    mcopy((void *)addr, src, n);
    VirtualProtect((void *)addr, n, oldprot, &tmp);
    FlushInstructionCache(GetCurrentProcess(), (void *)addr, n);
    return 1;
}
static void rollback_to(u32 mark) {
    while (g_nundo > mark) {
        Undo *u = &g_undo[--g_nundo];
        DWORD oldprot, tmp;
        if (VirtualProtect((void *)u->addr, u->n, PAGE_EXECUTE_RW, &oldprot)) {
            mcopy((void *)u->addr, u->old, u->n);
            VirtualProtect((void *)u->addr, u->n, oldprot, &tmp);
            FlushInstructionCache(GetCurrentProcess(), (void *)u->addr, u->n);
        }
    }
}

/* ---- the installer -------------------------------------------------------------------------- */
static u32 g_delta;
#define IMGPTR(va) ((u8 *)((va) + g_delta))

static int expect_bytes(const char *what, u32 va, const u8 *exp, u32 n) {
    u32 i; const u8 *p = IMGPTR(va);
    for (i = 0; i < n; i++) if (p[i] != exp[i]) {
        Ls("MISMATCH at "); Lx(va); Ls(" ("); Ls(what); Ls("), byte +"); Ld(i);
        Ls(": found "); Lx(p[i]); Ls(", expected "); Lx(exp[i]); Ls("\r\n");
        return 0;
    }
    return 1;
}

static void release_all(u8 *tbl, u8 *stubmem) {
    if (tbl)     VirtualFree(tbl, 0, MEM_RELEASE);
    if (stubmem) VirtualFree(stubmem, 0, MEM_RELEASE);
}

static const Profile *find_profile(const u8 *img) {
    u32 pe = rd32(img + 0x3c), i;
    if (img[0] != 'M' || img[1] != 'Z') { Ls("no MZ header\r\n"); return 0; }
    if (rd32(img + pe) != 0x00004550u) { Ls("no PE header\r\n"); return 0; }
    for (i = 0; i < sizeof g_profiles / sizeof g_profiles[0]; i++)
        if (rd32(img + pe + 8) == g_profiles[i]->timestamp && rd32(img + pe + 24 + 56) == g_profiles[i]->sizeofimage)
            return g_profiles[i];
    Ls("this exe is not a supported build (PE timestamp "); Lx(rd32(img + pe + 8)); Ls(", image size "); Lx(rd32(img + pe + 24 + 56));
    Ls("). Supported: ");
    for (i = 0; i < sizeof g_profiles / sizeof g_profiles[0]; i++) { Ls(g_profiles[i]->name); Ls(i + 1 < sizeof g_profiles / sizeof g_profiles[0] ? ", " : ".\r\n"); }
    Ls("Nothing patched.\r\n");
    return 0;
}

/* ---- section: archive limit ------------------------------------------------------------------- */
static int sect_archives(const Profile *pf, u32 maxa) {
    u32 B, mask, mulv, nent, i, k, total, off, table_va, end_va, mark = g_nundo;
    u8 *tbl = 0, *stubmem = 0;

    if (maxa > MAX_ARCHIVES_CAP) { Ls("above the supported maximum, using "); Ld(MAX_ARCHIVES_CAP); Ls("\r\n"); maxa = MAX_ARCHIVES_CAP; }
    B = 8; while (((1u << B) - 1u) < maxa) B++;
    mask = (1u << B) - 1u;           /* highest index; doubles as the "no archive" marker */
    nent = mask;                     /* usable archives = 2^B - 1 */
    mulv = 1u << B;
    Ls("archive index bits "); Ld(B); Ls(" -> "); Ld(nent); Ls(" archives, each up to "); { u32 mb = (1u << (32 - B)) >> 9; Ld(mb > 4096u ? 4096u : mb); } Ls(" MB\r\n");
    table_va = pf->table_va;
    end_va = table_va + STOCK_ENTRIES * ENTRY_SIZE;

    /* ---- verify every spot before touching anything ---- */
    for (i = 0; i < pf->nbody; i++)
        if (rd32(IMGPTR(pf->body[i].site)) != pf->body[i].target + g_delta) {
            Ls("MISMATCH at table reference "); Lx(pf->body[i].site); Ls("\r\n"); return 0;
        }
    for (i = 0; i < pf->nsent; i++)
        if (rd32(IMGPTR(pf->sent[i].site)) != pf->sent[i].target + g_delta) {
            Ls("MISMATCH at table-end reference "); Lx(pf->sent[i].site); Ls("\r\n"); return 0;
        }
    for (i = 0; i < pf->nhooks; i++) {
        const HookDef *h = &pf->hooks[i];
        if (!expect_bytes("hook", h->va, h->orig, h->len)) return 0;
    }
    for (i = 0; i < pf->nbp; i++)
        if (!expect_bytes("byte patch", pf->bp[i].va, pf->bp[i].orig, pf->bp[i].len)) return 0;
    if (rd32(IMGPTR(table_va + 0x98u)) == 0xFFFFFFFFu || *IMGPTR(table_va + 0x10u) != 0) {
        Ls("the game has already initialised its archive table - this plugin loaded too late.\r\n"
           "Load it as an .asi through the ASI loader (it must be present at startup). Archive limit not changed.\r\n");
        return 0;
    }

    /* ---- memory ---- */
    tbl = (u8 *)VirtualAlloc(0, (nent + 1) * ENTRY_SIZE, MEM_COMMIT_RESERVE, PAGE_READWRITE);
    if (!tbl) { Ls("VirtualAlloc for the table failed\r\n"); return 0; }
    /* the game compares table pointers with signed jl/jge: keep the whole table below 2 GB */
    if ((u32)tbl + (nent + 1) * ENTRY_SIZE >= 0x7FFF0000u) {
        Ls("table landed above 2 GB, refusing (signed pointer compares in the game)\r\n"); release_all(tbl, 0); return 0;
    }
    total = 0;
    for (i = 0; i < pf->nhooks; i++) total += (pf->stubs[pf->hooks[i].stub].size + 15u) & ~15u;
    /* the stubs are written into plain read/write memory and only then made execute/read-only:
       no page is ever writable and executable at the same time */
    stubmem = (u8 *)VirtualAlloc(0, total, MEM_COMMIT_RESERVE, PAGE_READWRITE);
    if (!stubmem) { Ls("VirtualAlloc for the stubs failed\r\n"); release_all(tbl, 0); return 0; }
    Ls("new table at "); Lx((u32)tbl); Ls(", stubs at "); Lx((u32)stubmem); Ls("\r\n");

    mcopy(tbl, IMGPTR(table_va), STOCK_ENTRIES * ENTRY_SIZE);

    /* ---- build every stub, then seal the stub memory ---- */
    off = 0;
    for (i = 0; i < pf->nhooks; i++) {
        const HookDef *h = &pf->hooks[i];
        const StubDef *sd = &pf->stubs[h->stub];
        u8 *dst = stubmem + off;
        mcopy(dst, sd->code, sd->size);
        for (k = 0; k < sd->nfix; k++) {
            u8 *f = dst + sd->fix[k].off;
            switch (sd->fix[k].kind) {
            case 0: wr32l(f, mask);  break;
            case 1: wr32l(f, ~mask); break;
            case 2: wr32l(f, mulv);  break;
            case 3: *f = (u8)B;      break;
            case 4: *f = (u8)(32 - B); break;
            case 5: wr32l(f, (h->va + h->len + g_delta) - (u32)(f + 4)); break;   /* jmp back, relative to the end of the jmp */
            }
        }
        off += (sd->size + 15u) & ~15u;
    }
    {
        DWORD oldprot;
        if (!VirtualProtect(stubmem, total, PAGE_EXECUTE_READ, &oldprot)) {
            Ls("could not make the stub memory executable - archive limit not changed.\r\n");
            release_all(tbl, stubmem); return 0;
        }
        FlushInstructionCache(GetCurrentProcess(), stubmem, total);
    }

    /* ---- apply ---- */
    for (i = 0; i < pf->nbody; i++) {
        u32 nv = (u32)tbl + (pf->body[i].target - table_va);
        if (!patch_write((u32)IMGPTR(pf->body[i].site), &nv, 4)) goto fail;
    }
    for (i = 0; i < pf->nsent; i++) {
        u32 nv = (u32)tbl + nent * ENTRY_SIZE + (pf->sent[i].target - end_va);
        if (!patch_write((u32)IMGPTR(pf->sent[i].site), &nv, 4)) goto fail;
    }
    off = 0;
    for (i = 0; i < pf->nhooks; i++) {
        const HookDef *h = &pf->hooks[i];
        const StubDef *sd = &pf->stubs[h->stub];
        u8 *dst = stubmem + off;
        u8 site[40];
        /* jmp rel32 into the stub, rest of the original region becomes nops */
        site[0] = 0xE9;
        wr32l(site + 1, (u32)dst - ((u32)IMGPTR(h->va) + 5));
        for (k = 5; k < h->len; k++) site[k] = 0x90;
        if (!patch_write((u32)IMGPTR(h->va), site, h->len)) goto fail;
        off += (sd->size + 15u) & ~15u;
    }
    for (i = 0; i < pf->nbp; i++) {
        const BytePatch *p = &pf->bp[i];
        u8 buf[4]; u32 n = 1;
        switch (p->kind) {
        case 0: wr32l(buf, mask); n = 4; break;
        case 1: buf[0] = (u8)B; break;
        case 2: buf[0] = (u8)(32 - B); break;
        default: buf[0] = p->value; break;
        }
        if (!patch_write((u32)IMGPTR(p->va) + p->immoff, buf, n)) goto fail;
    }
    Ls("OK: "); Ld(nent); Ls(" archives enabled ("); Ld(g_nundo - mark); Ls(" patches applied).\r\n");
    g_stub_base = (u32)stubmem; g_stub_size = total;
    g_tbl_base = (u32)tbl;      g_tbl_size = (nent + 1) * ENTRY_SIZE;  g_arch_entries = nent;
    g_use_base = (u32)tbl;      g_use_entries = nent;
    return 1;

fail:
    Ls("a write failed - rolling this section back.\r\n");
    rollback_to(mark);
    release_all(tbl, stubmem);
    return 0;
}

/* ---- section: streaming memory budgets (vehicle / ped) -------------------------------------------- */
#define BUDGET_MIN   1000000u
#define BUDGET_MAX   0x7FFFFFFFu        /* the game compares these as signed 32-bit numbers */

static int sect_budget(const char *what, const BudgetVar *bv, u32 value, u32 overwrite) {
    u32 i, cur;
    if (value < BUDGET_MIN || value > BUDGET_MAX) {
        Ls(what); Ls(": Value "); Ld(value); Ls(" is outside "); Ld(BUDGET_MIN); Ls(" .. "); Ld(BUDGET_MAX); Ls(", not changed.\r\n");
        return 0;
    }
    for (i = 0; i < bv->nref; i++)
        if (rd32(IMGPTR(bv->ref[i])) != bv->va + g_delta) {
            Ls("MISMATCH at "); Ls(what); Ls(" reference "); Lx(bv->ref[i]); Ls(" - not changed.\r\n"); return 0;
        }
    cur = rd32(IMGPTR(bv->va));
    Ls(what); Ls(": variable at "); Lx(bv->va); Ls(" holds "); Ld(cur); Ls(" (game default "); Ld(bv->stock); Ls(")\r\n");
    if (cur == value) { Ls(what); Ls(": already "); Ld(value); Ls(", nothing to do.\r\n"); return 1; }
    if (cur != bv->stock && !overwrite) {
        Ls(what); Ls(": not the game default - another mod or an exe patch has already changed it. Left alone (set Overwrite=1 to force).\r\n");
        return 1;
    }
    if (!patch_write((u32)IMGPTR(bv->va), &value, 4)) { Ls(what); Ls(": write failed, not changed.\r\n"); return 0; }
    Ls(what); Ls(": OK, set to "); Ld(value); Ls(" bytes");
    if (value > 400000000u) Ls("  (very large: this can starve the rest of the streaming memory)");
    Ls("\r\n");
    return 1;
}

/* ---- section: crash logger ---------------------------------------------------------------------------
 * A vectored exception handler that logs serious exceptions and then returns EXCEPTION_CONTINUE_SEARCH (0), i.e. it
 * never handles, changes or hides anything: the game crashes (or recovers) exactly as without it. It runs on the
 * crashing thread, so it uses only static buffers, no heap and no CRT, and it reads other memory only after
 * VirtualQuery said that memory is committed and readable.
 *
 * These are FIRST-chance exceptions: if the game or another mod handles one, the log still shows it. The last entry before
 * the game closes is the one that matters. Every faulting address (code + exception code) is reported in full twice, in a
 * short form up to 20 times, and then no more, so a harmless exception that happens thousands of times cannot flood the file.
 * Records are appended to HULKSMASH.crash.log, which survives restarts of the game (it is cut back if it grows past 512 KB).
 */
#ifndef GET_PEB
#define GET_PEB() ({ u32 _p; __asm__ volatile("movl %%fs:0x30, %0" : "=r"(_p)); _p; })
#endif
typedef i32 LONG;
typedef struct { u32 code, flags, chain, addr, nparams, info[15]; } ExcRec;     /* EXCEPTION_RECORD   */
typedef struct { ExcRec *rec; u32 *ctx; } ExcPtrs;                                /* EXCEPTION_POINTERS */
typedef struct { u32 base, size; char name[28]; } ModInfo;
typedef struct { u32 code, eip, count; } CrashSite;

#define CL_MAXMODS       192u
#define CL_MAXSITES      64u
#define CL_FULL_MAX      2u        /* full records per faulting address            */
#define CL_COMPACT_MAX   20u       /* short records per faulting address (incl. the full ones) */
#define CL_OVERFLOW_MAX  100u      /* short records for addresses that no longer fit the site table */
#define CL_STACK_DWORDS  128u
#define CL_FILE_MAX      524288u
/* CONTEXT (x86) dword indexes */
#define CX_EDI 39
#define CX_ESI 40
#define CX_EBX 41
#define CX_EDX 42
#define CX_ECX 43
#define CX_EAX 44
#define CX_EBP 45
#define CX_EIP 46
#define CX_EFL 48
#define CX_ESP 49

static u32        g_cl_on;
static char       g_cl_path[300];
static HANDLE     g_cl_file = INVALID_HANDLE;
static char       g_cl_buf[4096];
static u32        g_cl_n;
static volatile u32 g_cl_busy;
static const char *g_cl_build;
static u32        g_cl_pets, g_cl_main, g_cl_t0, g_cl_seq, g_cl_banner, g_cl_modprints, g_cl_lastnmods, g_cl_over;
static u32        g_cl_nsites, g_cl_nmods;
static CrashSite  g_cl_sites[CL_MAXSITES];
static ModInfo    g_cl_mods[CL_MAXMODS];
static u32        g_cl_stk[CL_STACK_DWORDS];

typedef struct { u32 base, alloc_base, alloc_prot, size, state, prot, type; } MemInfo;     /* MEMORY_BASIC_INFORMATION */

/* copy n bytes from addr into dst, but only if every page is committed and readable; 0 = not readable (nothing is touched) */
__attribute__((noinline)) static int cl_read(u32 addr, void *dst, u32 n) {
    u8 *d = (u8 *)dst;
    while (n) {
        MemInfo q; u32 avail, m;
        if (VirtualQuery((const void *)addr, &q, sizeof q) < sizeof q) return 0;
        if (q.state != 0x1000u || (q.prot & 0x100u) || !(q.prot & 0xEEu)) return 0;     /* not committed / guard page / no read access */
        avail = q.base + q.size - addr;                                                /* may wrap to 0 at the very top: handled below */
        m = n < avail ? n : avail;
        if (m == 0) return 0;
        mcopy(d, (const void *)addr, m);
        d += m; addr += m; n -= m;
    }
    return 1;
}

__attribute__((noinline)) static void cl_flush(void) {
    DWORD w;
    if (g_cl_file != INVALID_HANDLE && g_cl_n) WriteFile(g_cl_file, g_cl_buf, g_cl_n, &w, 0);
    g_cl_n = 0;
}
__attribute__((noinline)) static void cl_c(char c) { if (g_cl_n >= sizeof g_cl_buf) cl_flush(); g_cl_buf[g_cl_n++] = c; }
__attribute__((noinline)) static void cl_s(const char *s) { while (*s) cl_c(*s++); }
__attribute__((noinline)) static void cl_x(u32 v) {                       /* hex, no leading zeros */
    static const char H[] = "0123456789abcdef";
    char t[8]; int n = 0;
    do { t[n++] = H[v & 15]; v >>= 4; } while (v);
    while (n) cl_c(t[--n]);
}
__attribute__((noinline)) static void cl_x8(u32 v) {                      /* hex, always 8 digits */
    static const char H[] = "0123456789abcdef";
    int i;
    for (i = 28; i >= 0; i -= 4) cl_c(H[(v >> i) & 15]);
}
__attribute__((noinline)) static void cl_dn(u32 v, u32 width) {           /* decimal, zero padded to width */
    char t[11]; u32 n = 0;
    do { t[n++] = (char)('0' + v % 10); v /= 10; } while (v);
    while (n < width) t[n++] = '0';
    while (n) cl_c(t[--n]);
}

static const char *cl_codename(u32 c) {         /* 0 = not an exception this logger records */
    if (c == 0xC0000005u) return "ACCESS VIOLATION";
    if (c == 0xC0000006u) return "IN-PAGE ERROR";
    if (c == 0xC000001Du) return "ILLEGAL INSTRUCTION";
    if (c == 0xC0000096u) return "PRIVILEGED INSTRUCTION";
    if (c == 0xC0000094u) return "INTEGER DIVIDE BY ZERO";
    if (c == 0xC0000095u) return "INTEGER OVERFLOW";
    if (c == 0xC000008Cu) return "ARRAY BOUNDS EXCEEDED";
    if (c == 0xC0000374u) return "HEAP CORRUPTION";
    return 0;
}

/* the loaded modules, from the loader list in the PEB (read without taking the loader lock, every pointer checked first) */
__attribute__((noinline)) static void cl_collect_modules(void) {
    u32 peb = GET_PEB(), ldr = 0, head, cur = 0, guard = 0;
    g_cl_nmods = 0;
    if (!peb || !cl_read(peb + 0x0c, &ldr, 4) || !ldr) return;
    head = ldr + 0x0c;                                          /* PEB_LDR_DATA.InLoadOrderModuleList */
    if (!cl_read(head, &cur, 4)) return;
    while (cur && cur != head && guard++ < 600u && g_cl_nmods < CL_MAXMODS) {
        u8 e[0x34]; u16 nm[28]; u32 nlen, nbuf, j, nxt; ModInfo *m = &g_cl_mods[g_cl_nmods];
        if (!cl_read(cur, e, sizeof e)) break;
        nxt = rd32(e);
        m->base = rd32(e + 0x18); m->size = rd32(e + 0x20);      /* LDR_DATA_TABLE_ENTRY.DllBase / SizeOfImage */
        nlen = (u32)(e[0x2c] | (e[0x2d] << 8)) / 2u;             /* BaseDllName (UNICODE_STRING at +0x2c) */
        nbuf = rd32(e + 0x30);
        m->name[0] = '?'; m->name[1] = 0;
        if (nlen > 27u) nlen = 27u;
        if (nbuf && nlen && cl_read(nbuf, nm, nlen * 2u)) {
            for (j = 0; j < nlen; j++) m->name[j] = (nm[j] >= 32 && nm[j] < 127) ? (char)nm[j] : '?';
            m->name[nlen] = 0;
        }
        if (m->base && m->size) g_cl_nmods++;
        if (nxt == cur) break;
        cur = nxt;
    }
}

/* names an address: inside a loaded module, or inside the memory this plugin allocated. Returns 1 if it did. */
__attribute__((noinline)) static int cl_describe(u32 a, int print) {
    u32 i;
    if (g_stub_size && a - g_stub_base < g_stub_size) {
        if (print) { cl_s(" = HULKSMASH stub +0x"); cl_x(a - g_stub_base); }
        return 1;
    }
    if (g_tbl_size && a - g_tbl_base < g_tbl_size) {
        if (print) { cl_s(" = HULKSMASH archive table +0x"); cl_x(a - g_tbl_base); }
        return 1;
    }
    for (i = 0; i < g_cl_nmods; i++)
        if (a - g_cl_mods[i].base < g_cl_mods[i].size) {
            if (print) {
                cl_s(" = "); cl_s(g_cl_mods[i].name); cl_s("+0x"); cl_x(a - g_cl_mods[i].base);
                if (g_cl_mods[i].base == g_cl_main) { cl_s(" (exe address as in the unrelocated file: 0x"); cl_x8(a - g_cl_main + IMG_PREFBASE); cl_s(")"); }
            }
            return 1;
        }
    return 0;
}
static void cl_addr(u32 a) { cl_s("0x"); cl_x8(a); cl_describe(a, 1); }

__attribute__((noinline)) static void cl_regs(const u32 *cx) {
    cl_s("  eax="); cl_x8(cx[CX_EAX]); cl_s(" ebx="); cl_x8(cx[CX_EBX]); cl_s(" ecx="); cl_x8(cx[CX_ECX]); cl_s(" edx="); cl_x8(cx[CX_EDX]); cl_s("\r\n");
    cl_s("  esi="); cl_x8(cx[CX_ESI]); cl_s(" edi="); cl_x8(cx[CX_EDI]); cl_s(" ebp="); cl_x8(cx[CX_EBP]); cl_s(" esp="); cl_x8(cx[CX_ESP]);
    cl_s(" efl="); cl_x8(cx[CX_EFL]); cl_s("\r\n");
}

/* up to maxd dwords from esp, 4 per line; returns how many could be read */
__attribute__((noinline)) static u32 cl_stack(u32 esp, u32 maxd, u32 print) {
    u32 got = 0, k;
    while (got < maxd) {
        u32 line[4];
        if (!cl_read(esp + got * 4u, line, 16)) break;
        if (print) {
            cl_s("  esp+0x"); cl_x(got * 4u); cl_s(": ");
            for (k = 0; k < 4; k++) { cl_x8(line[k]); cl_c(k < 3 ? ' ' : '\r'); }
            cl_c('\n');
        }
        for (k = 0; k < 4; k++) if (got + k < CL_STACK_DWORDS) g_cl_stk[got + k] = line[k];
        got += 4;
    }
    if (print && got < maxd) { cl_s("  esp+0x"); cl_x(got * 4u); cl_s(": <memory not readable>\r\n"); }
    return got;
}

__attribute__((noinline)) static void cl_header(u32 seq, u32 cnt) {
    u16 st[8];
    u32 secs = (GetTickCount() - g_cl_t0) / 1000u;
    GetLocalTime(st);
    cl_s("local time "); cl_dn(st[0], 4); cl_c('-'); cl_dn(st[1], 2); cl_c('-'); cl_dn(st[3], 2); cl_c(' ');
    cl_dn(st[4], 2); cl_c(':'); cl_dn(st[5], 2); cl_c(':'); cl_dn(st[6], 2);
    cl_s(", "); cl_dn(secs, 1); cl_s(" s after the plugin loaded, thread "); cl_dn(GetCurrentThreadId(), 1);
    cl_s(", exception #"); cl_dn(seq, 1); cl_s(", occurrence "); cl_dn(cnt, 1); cl_s(" at this address\r\n");
}

/* how many archive slots are in use at this moment (full records only) */
__attribute__((noinline)) static void cl_usage_line(void) {
    if (!g_use_base) return;
    cl_s("  archives in use: "); cl_dn(archives_in_use(), 1); cl_s(" of "); cl_dn(g_use_entries, 1);
    cl_s(g_tbl_size ? "\r\n" : " (the game's own table; the ArchiveLimit section is not active)\r\n");
}

__attribute__((noinline)) static void cl_code_line(const ExcRec *er) {
    const char *nm = cl_codename(er->code);
    cl_s("  code 0x"); cl_x8(er->code); cl_c(' '); cl_s(nm ? nm : "?");
    if ((er->code == 0xC0000005u || er->code == 0xC0000006u) && er->nparams >= 2) {
        u32 t = er->info[0];
        cl_s(t == 0 ? ", read of address 0x" : t == 1 ? ", write to address 0x" : t == 8 ? ", execute (DEP) at address 0x" : ", access type ?, address 0x");
        cl_x8(er->info[1]);
    }
    cl_s("\r\n");
}

static void usage_note(u32 seq);              /* archive usage report, below */

static LONG WINAPI cl_handler(ExcPtrs *ep) {
    ExcRec *er; u32 *cx, code, eip, i, site, cnt, mode, seq, untracked = 0;
    if (!ep) return 0;
    er = ep->rec; cx = ep->ctx;
    if (!er || !cx) return 0;
    code = er->code;
    if (!cl_codename(code)) return 0;                               /* C++ exceptions, thread names, breakpoints, stack overflow ... */
    if (__sync_lock_test_and_set(&g_cl_busy, 1)) return 0;          /* another thread is logging right now: skip, never wait */
    eip = cx[CX_EIP];

    /* which address, how often */
    for (site = 0; site < g_cl_nsites; site++) if (g_cl_sites[site].code == code && g_cl_sites[site].eip == eip) break;
    if (site < g_cl_nsites) cnt = ++g_cl_sites[site].count;
    else if (g_cl_nsites < CL_MAXSITES) { g_cl_sites[g_cl_nsites].code = code; g_cl_sites[g_cl_nsites].eip = eip; g_cl_sites[g_cl_nsites].count = 1; g_cl_nsites++; cnt = 1; }
    else { untracked = 1; cnt = ++g_cl_over; }                      /* more different addresses than the table holds */
    if (untracked) mode = cnt <= CL_OVERFLOW_MAX ? 2u : 0u;
    else           mode = cnt <= CL_FULL_MAX ? 1u : cnt <= CL_COMPACT_MAX ? 2u : cnt == CL_COMPACT_MAX + 1u ? 3u : 0u;
    if (!mode) goto done;
    seq = ++g_cl_seq;

    g_cl_file = CreateFileA(g_cl_path, 4u /* FILE_APPEND_DATA */, 3u, 0, 4u /* OPEN_ALWAYS */, 0x80u, 0);
    if (g_cl_file == INVALID_HANDLE) goto done;
    g_cl_n = 0;
    if (!g_cl_banner) {
        g_cl_banner = 1;
        cl_s("\r\n######## game session: HULKSMASH 1.5.1 crash log ########\r\n");
        cl_s("exe: GTAIV.exe at 0x"); cl_x8(g_cl_main); cl_s(", ");
        if (g_cl_build) cl_s(g_cl_build); else { cl_s("unrecognised build (PE timestamp 0x"); cl_x8(g_cl_pets); cl_s(")"); }
        cl_s("\r\n");
        if (g_tbl_size) { cl_s("archive limit: "); cl_dn(g_arch_entries, 1); cl_s(" archives, table at 0x"); cl_x8(g_tbl_base); cl_s(", stubs at 0x"); cl_x8(g_stub_base); cl_s("\r\n"); }
        else cl_s("archive limit: not active\r\n");
    }
    cl_collect_modules();

    if (mode == 3u) {                                               /* the cap for this address was reached */
        cl_s("-- exception #"); cl_dn(seq, 1); cl_s(": ["); cl_s(cl_codename(code)); cl_s(" at "); cl_addr(eip);
        cl_s("] has now happened "); cl_dn(cnt, 1); cl_s(" times; no further occurrences from this address are logged\r\n");
    } else if (mode == 2u) {                                        /* short form */
        cl_s("-- "); cl_header(seq, cnt);
        if (untracked) cl_s("  (more than 64 different addresses have raised exceptions: this one is not tracked on its own, the number above counts all such)\r\n");
        cl_code_line(er);
        cl_s("  at "); cl_addr(eip); cl_s("\r\n");
        cl_regs(cx);
        cl_stack(cx[CX_ESP], 16u, 1u);
    } else {                                                        /* full record */
        u8 code_bytes[16];
        u32 got, r;
        cl_s("==== "); cl_header(seq, cnt);
        cl_s("  This is a first-chance exception: the game or another mod may still handle it. If the game closed right after\r\n"
             "  this entry, this is the crash.\r\n");
        cl_code_line(er);
        cl_usage_line();
        cl_s("  eip "); cl_addr(eip); cl_s("\r\n");
        if (!cl_describe(eip, 0)) {
            MemInfo q;
            if (VirtualQuery((const void *)eip, &q, sizeof q) >= sizeof q) {
                cl_s("  (not inside any loaded module; memory region starts at 0x"); cl_x8(q.base); cl_s(", allocation base 0x"); cl_x8(q.alloc_base);
                cl_s(", state 0x"); cl_x(q.state); cl_s(", protect 0x"); cl_x(q.prot); cl_s(", type 0x"); cl_x(q.type); cl_s(")\r\n");
            }
        }
        if (cl_read(eip, code_bytes, 16)) {
            cl_s("  bytes at eip:");
            for (i = 0; i < 16; i++) { cl_c(' '); cl_c("0123456789abcdef"[code_bytes[i] >> 4]); cl_c("0123456789abcdef"[code_bytes[i] & 15]); }
            cl_s("\r\n");
        } else cl_s("  bytes at eip: <memory not readable>\r\n");
        cl_s("registers:\r\n");
        cl_regs(cx);
        {   /* registers that point into a module / this plugin's memory */
            static const char *const rn[7] = { "eax", "ebx", "ecx", "edx", "esi", "edi", "ebp" };
            static const u8 ri[7] = { CX_EAX, CX_EBX, CX_ECX, CX_EDX, CX_ESI, CX_EDI, CX_EBP };
            for (r = 0; r < 7; r++) if (cl_describe(cx[ri[r]], 0)) { cl_s("  "); cl_s(rn[r]); cl_s(" = "); cl_addr(cx[ri[r]]); cl_s("\r\n"); }
            cl_s("memory the registers point at (8 dwords each):\r\n");
            for (r = 0; r < 7; r++) {
                u32 v = cx[ri[r]], w[8], k;
                if (v >= 0x10000u && cl_read(v, w, 32)) {
                    cl_s("  ["); cl_s(rn[r]); cl_s("="); cl_x8(v); cl_s("]:");
                    for (k = 0; k < 8; k++) { cl_c(' '); cl_x8(w[k]); }
                    cl_s("\r\n");
                }
            }
        }
        cl_s("stack ("); cl_dn(CL_STACK_DWORDS, 1); cl_s(" dwords from esp):\r\n");
        got = cl_stack(cx[CX_ESP], CL_STACK_DWORDS, 1u);
        cl_s("stack values that point into a module or this plugin's memory:\r\n");
        {
            u32 shown = 0;
            for (i = 0; i < got && shown < 64u; i++) if (cl_describe(g_cl_stk[i], 0)) { cl_s("  esp+0x"); cl_x(i * 4u); cl_s(": "); cl_addr(g_cl_stk[i]); cl_s("\r\n"); shown++; }
        }
        if (g_cl_modprints < 4u && (g_cl_modprints == 0 || g_cl_nmods != g_cl_lastnmods)) {
            g_cl_modprints++; g_cl_lastnmods = g_cl_nmods;
            cl_s("loaded modules ("); cl_dn(g_cl_nmods, 1); cl_s("):\r\n");
            for (i = 0; i < g_cl_nmods; i++) {
                cl_s("  0x"); cl_x8(g_cl_mods[i].base); cl_s("  size 0x"); cl_x(g_cl_mods[i].size); cl_s("  "); cl_s(g_cl_mods[i].name); cl_s("\r\n");
            }
        }
        cl_s("\r\n");
    }
    cl_flush();
    if (mode == 1u) usage_note(seq);                                /* full record: also the [Usage] line, if the count is new */
done:
    if (g_cl_file != INVALID_HANDLE) { CloseHandle(g_cl_file); g_cl_file = INVALID_HANDLE; }
    __sync_lock_release(&g_cl_busy);
    return 0;                                                       /* EXCEPTION_CONTINUE_SEARCH: the exception is not touched */
}

static void cl_make_path(char *dst, const char *ext) {
    u32 n = 0, k;
    for (k = 0; g_base_path[k] && k < 270; k++) dst[n++] = g_base_path[k];
    while (*ext) dst[n++] = *ext++;
    dst[n] = 0;
}
static void append_text(const char *ext, const char *text) {
    char path[300]; HANDLE f; DWORD w; u32 n = 0;
    while (text[n]) n++;
    cl_make_path(path, ext);
    f = CreateFileA(path, 4u, 3u, 0, 4u, 0x80u, 0);
    if (f != INVALID_HANDLE) { WriteFile(f, text, n, &w, 0); CloseHandle(f); }
}

/* called from DllMain after the install log has been written */
static void crashlog_start(void) {
    HANDLE h;
    if (!g_cl_on || !g_base_path[0]) return;
    cl_make_path(g_cl_path, ".crash.log");
    h = CreateFileA(g_cl_path, 0x80000000u, 3u, 0, 3u /* OPEN_EXISTING */, 0x80u, 0);        /* keep the file from growing for ever */
    if (h != INVALID_HANDLE) {
        DWORD sz = GetFileSize(h, 0);
        CloseHandle(h);
        if (sz != 0xFFFFFFFFu && sz > CL_FILE_MAX) {
            h = CreateFileA(g_cl_path, 0x40000000u, 3u, 0, 2u /* CREATE_ALWAYS */, 0x80u, 0);
            if (h != INVALID_HANDLE) CloseHandle(h);
        }
    }
    g_cl_main = (u32)GetModuleHandleA(0);
    g_cl_t0 = GetTickCount();
    {   /* which build is this (quietly - the install log already has the details) */
        const u8 *img = (const u8 *)g_cl_main; u32 pe, i;
        g_cl_build = 0; g_cl_pets = 0;
        if (img[0] == 'M' && img[1] == 'Z') {
            pe = rd32(img + 0x3c);
            if (rd32(img + pe) == 0x00004550u) {
                g_cl_pets = rd32(img + pe + 8);
                for (i = 0; i < sizeof g_profiles / sizeof g_profiles[0]; i++)
                    if (g_cl_pets == g_profiles[i]->timestamp && rd32(img + pe + 24 + 56) == g_profiles[i]->sizeofimage) g_cl_build = g_profiles[i]->name;
            }
        }
    }
    g_cl_file = INVALID_HANDLE;
    if (AddVectoredExceptionHandler(1u, (void *)cl_handler))
        append_text(".log", "[CrashLog] handler installed: serious exceptions are recorded in HULKSMASH.crash.log\r\n");
    else
        append_text(".log", "[CrashLog] AddVectoredExceptionHandler failed - no crash log this session\r\n");
}

/* ---- archive usage report ------------------------------------------------------------------------------
 * The plugin loads before the game reads a single .img, so the number of archives is not known at start-up. 1.4 started a
 * watcher thread for this; with that thread in the process TBoGT died of heap corruption shortly after loading (the thread
 * itself touched no heap - one more thread was enough to set something else off), so this version has no thread at all.
 * The table is counted (only READ) at two moments the plugin runs code anyway:
 *   - when the crash logger writes a full record - that covers a game that crashes, including the crash many setups have
 *     when the game is quit;
 *   - at DLL_PROCESS_DETACH, i.e. when the game closes normally.
 * A "[Usage] archives in use: N of M" line is added to HULKSMASH.log only for a count that is not 0 and differs from the
 * last one written (at most 8 lines). It touches nothing else.
 */
#define USAGE_MAX_LINES  8u

static u32  g_use_reported, g_use_lines;
static char g_um[300];
static u32  g_umn;
static void um_s(const char *s) { while (*s && g_umn < sizeof g_um - 1) g_um[g_umn++] = *s++; }
static void um_d(u32 v) {
    char t[11]; u32 n = 0;
    do { t[n++] = (char)('0' + v % 10); v /= 10; } while (v);
    while (n && g_umn < sizeof g_um - 1) g_um[g_umn++] = t[--n];
}

/* seq = the crash-log exception number that triggered the count, 0 = the game is closing */
static void usage_report(u32 n, u32 seq) {
    g_umn = 0;
    um_s("[Usage] archives in use: "); um_d(n); um_s(" of "); um_d(g_use_entries);
    if (seq) { um_s(" (at crash-log exception #"); um_d(seq); um_s(")"); } else um_s(" (when the game closed)");
    if (!g_tbl_size) um_s(" (the game's own table; the ArchiveLimit section is not active)");
    if (n >= g_use_entries) um_s(g_tbl_size ? " - THE TABLE IS FULL, further archives cannot be registered: raise MaxArchives in HULKSMASH.ini" : " - THE TABLE IS FULL");
    um_s("\r\n");
    g_um[g_umn] = 0;
    append_text(".log", g_um);
}

/* from cl_handler (full records only, under its busy flag) and from usage_closing */
static void usage_note(u32 seq) {
    u32 n;
    if (!g_use_on || !g_use_base || !g_base_path[0] || g_use_lines >= USAGE_MAX_LINES) return;
    n = archives_in_use();
    if (!n || n == g_use_reported) return;
    usage_report(n, seq);
    g_use_reported = n; g_use_lines++;
}

/* DLL_PROCESS_DETACH: the game is closing (the other threads are already gone) */
static void usage_closing(void) {
    if (!g_use_on || !g_use_base || !g_base_path[0]) return;
    if (!g_use_lines && !archives_in_use())
        append_text(".log", g_tbl_size ? "[Usage] no registered archive was seen in the plugin's table\r\n"
                                       : "[Usage] no registered archive was seen in the game's own table (another mod has probably moved it)\r\n");
    else usage_note(0);
}

/* the build, without logging anything (0 = not one of the supported builds) */
static const Profile *match_profile(const u8 *img) {
    u32 pe, i;
    if (img[0] != 'M' || img[1] != 'Z') return 0;
    pe = rd32(img + 0x3c);
    if (rd32(img + pe) != 0x00004550u) return 0;
    for (i = 0; i < sizeof g_profiles / sizeof g_profiles[0]; i++)
        if (rd32(img + pe + 8) == g_profiles[i]->timestamp && rd32(img + pe + 24 + 56) == g_profiles[i]->sizeofimage) return g_profiles[i];
    return 0;
}

/* called from DllMain after install(); the archive section has set g_use_base when it moved the table */
static void usage_init(void) {
    if (!g_use_on || !g_base_path[0] || g_use_base) return;
    {                                          /* the game's own table is in use: count that one, if this is a build we know */
        const Profile *pf = match_profile((const u8 *)GetModuleHandleA(0));
        if (!pf) return;
        g_use_base = pf->table_va + g_delta; g_use_entries = STOCK_ENTRIES;
    }
}

/* ---- the installer -------------------------------------------------------------------------- */
static char g_ini[280];
static u32 ini_int(const char *section, const char *key, u32 def) { return GetPrivateProfileIntA(section, key, (i32)def, g_ini); }

static int install(HANDLE self) {
    u32 k, maxa, arch_on, veh_on, ped_on, veh_val, ped_val, veh_ow, ped_ow, any = 0;
    const u8 *img;
    const Profile *pf;

    img = (const u8 *)GetModuleHandleA(0);
    g_delta = (u32)img - IMG_PREFBASE;
    Ls("HULKSMASH 1.5.1\r\nimage base "); Lx((u32)img); Ls(", delta "); Lx(g_delta); Ls("\r\n");

    /* ---- settings (HULKSMASH.ini next to this .asi) ---- */
    {
        u32 n = GetModuleFileNameA(self, g_base_path, 260);
        u32 dot = 0;
        if (n == 0 || n >= 260) { Ls("cannot get module path\r\n"); return 0; }
        for (k = 0; k < n; k++) {
            if (g_base_path[k] == '.') dot = k;
            if (g_base_path[k] == '\\' || g_base_path[k] == '/') dot = 0;
        }
        if (dot) g_base_path[dot] = 0;
        for (k = 0; g_base_path[k]; k++) g_ini[k] = g_base_path[k];
        g_ini[k++] = '.'; g_ini[k++] = 'i'; g_ini[k++] = 'n'; g_ini[k++] = 'i'; g_ini[k] = 0;
    }
    arch_on = ini_int("ArchiveLimit", "Enabled", 1);
    maxa    = ini_int("ArchiveLimit", "MaxArchives", 1023);
    veh_on  = ini_int("VehicleBudget", "Enabled", 0);
    veh_val = ini_int("VehicleBudget", "Value", 120000000u);
    veh_ow  = ini_int("VehicleBudget", "Overwrite", 0);
    ped_on  = ini_int("PedBudget", "Enabled", 0);
    ped_val = ini_int("PedBudget", "Value", 75000000u);
    ped_ow  = ini_int("PedBudget", "Overwrite", 0);
    g_cl_on = ini_int("CrashLog", "Enabled", 1);
    g_use_on = ini_int("ArchiveLimit", "ReportUsage", 1);

    Ls("[ArchiveLimit]  "); if (!arch_on) Ls("disabled\r\n"); else if (maxa <= STOCK_ENTRIES) { Ls("MaxArchives="); Ld(maxa); Ls(" (255 or less = stock behaviour, nothing to do)\r\n"); } else { Ls("enabled, MaxArchives="); Ld(maxa); Ls("\r\n"); }
    Ls("[VehicleBudget] "); if (veh_on) { Ls("enabled, Value="); Ld(veh_val); Ls(veh_ow ? ", Overwrite=1\r\n" : "\r\n"); } else Ls("disabled\r\n");
    Ls("[PedBudget]     "); if (ped_on) { Ls("enabled, Value="); Ld(ped_val); Ls(ped_ow ? ", Overwrite=1\r\n" : "\r\n"); } else Ls("disabled\r\n");
    Ls("[CrashLog]      "); Ls(g_cl_on ? "enabled (records go to HULKSMASH.crash.log)\r\n" : "disabled\r\n");
    Ls("[Usage]         "); Ls(g_use_on ? "enabled (ReportUsage=1: a [Usage] line is added to this log when the game closes or the crash log records an exception)\r\n" : "disabled (ReportUsage=0)\r\n");
    if (arch_on && maxa <= STOCK_ENTRIES) arch_on = 0;
    if (!arch_on && !veh_on && !ped_on) { Ls("Nothing enabled, nothing patched.\r\n"); return 1; }

    /* ---- which build is this? ---- */
    pf = find_profile(img);
    if (!pf) return 0;
    Ls("detected "); Ls(pf->name); Ls("\r\n");

    g_nundo = 0;
    if (arch_on) { Ls("-- ArchiveLimit\r\n"); any |= sect_archives(pf, maxa); }
    if (veh_on)  { Ls("-- VehicleBudget\r\n"); any |= sect_budget("VehicleBudget", pf->veh, veh_val, veh_ow); }
    if (ped_on)  { Ls("-- PedBudget\r\n");     any |= sect_budget("PedBudget", pf->ped, ped_val, ped_ow); }
    return any;
}

static void flush_log(void) {
    u32 k, n = 0;
    char path[290];
    HANDLE f; DWORD wrote;
    for (k = 0; g_base_path[k] && k < 270; k++) path[n++] = g_base_path[k];
    path[n++] = '.'; path[n++] = 'l'; path[n++] = 'o'; path[n++] = 'g'; path[n] = 0;
    f = CreateFileA(path, 0x40000000u, 1u, 0, 2u, 0x80u, 0);
    if (f != INVALID_HANDLE) { WriteFile(f, g_log, g_loglen, &wrote, 0); CloseHandle(f); }
}

BOOL WINAPI DllMain(HANDLE self, DWORD reason, LPVOID reserved) {
    (void)reserved;
    if (reason == 1) {                         /* DLL_PROCESS_ATTACH */
        DisableThreadLibraryCalls(self);
        install(self);
        flush_log();
        crashlog_start();                      /* independent of the patch sections; does nothing when [CrashLog] Enabled=0 */
        usage_init();                          /* independent of the patch sections; does nothing when ReportUsage=0 */
    } else if (reason == 0) {                  /* DLL_PROCESS_DETACH */
        usage_closing();
    }
    return 1;
}
