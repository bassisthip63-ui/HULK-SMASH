#!/bin/sh
# Build HULKSMASH.asi (32-bit Windows DLL) with clang + lld on Linux.
set -e
cd "$(dirname "$0")"
# src/profiles_gen.h is shipped pre-generated. To regenerate it (and re-verify every byte against the real exes):
#   EXE_1070=/path/1.0.7.0/GTAIV.exe EXE_1080=/path/1.0.8.0/GTAIV.exe EXE_1259=/path/1.2.0.59/GTAIV.exe ./build.sh
if [ -n "${EXE_1070:-}" ] && [ -n "${EXE_1080:-}" ] && [ -n "${EXE_1259:-}" ]; then
  python3 -I tools/gen_profiles.py "$EXE_1070" "$EXE_1080" "$EXE_1259" src/profiles_gen.h
fi
llvm-dlltool -m i386 -k -d build/kernel32.def -l build/kernel32.lib
llvm-rc /fo build/version.res build/version.rc
clang --target=i686-pc-windows-msvc -O2 -ffreestanding -fno-builtin -fno-stack-protector \
      -fno-asynchronous-unwind-tables -fno-unwind-tables -Wall -Wextra -Wno-unused-function \
      -c src/archive_limit.c -o build/archive_limit.obj
lld-link /dll /nodefaultlib /entry:DllMain@12 /subsystem:windows,5.01 /machine:x86 \
         /filealign:512 /opt:ref /opt:icf /dynamicbase /nxcompat /map:build/HULKSMASH.map /out:HULKSMASH.asi \
         build/archive_limit.obj build/kernel32.lib build/version.res
python3 -I tools/pe_checksum.py HULKSMASH.asi
ls -l HULKSMASH.asi
