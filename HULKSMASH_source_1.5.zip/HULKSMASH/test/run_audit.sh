#!/bin/sh
# run_audit.sh GTAIV.exe WORKDIR : patch flat images in the harness and audit every byte that changed
set -u
cd "$(dirname "$0")/.."
EXE=$1; W=$2; mkdir -p "$W"; rc=0
sh test/build_test.sh || exit 2
for b in 400000 20000000 30000000; do [ -f "$W/img_$b.bin" ] || python3 test/mkimage.py "$EXE" 0x$b "$W/img_$b.bin" >/dev/null; done
for cfg in "400000 300" "400000 1023" "400000 2047" "30000000 511" "30000000 2047"; do
  set -- $cfg
  out=$(./test/harness "$W/img_20000000.bin" 0x20000000 "$W/img_$1.bin" 0x$1 "$W" $2 "$W/dump_$1_$2.bin" 2>&1 | grep -E '^new table|^B = ' )
  newt=$(echo "$out" | sed -n 's/^new table at \(0x[0-9a-f]*\)$/\1/p' | head -1); mask=$(echo "$out" | sed -n 's/^B = .*mask = //p')
  res=$(python3 -I test/audit.py "$W/img_$1.bin" "$W/dump_$1_$2.bin" 0x$1 $newt $mask | grep -E '^(P1|changed bytes|remap|AUDIT|planned|ped budget|veh budget)' | tr '\n' ' ')
  echo "base=$1 max=$2: $res"
  echo "$res" | grep -q 'AUDIT PASSED' || rc=1
done
exit $rc
