#!/bin/sh
set -e
cd "$(dirname "$0")/.."
clang --target=i386-linux-gnu -m32 -static -nostdlib -ffreestanding -fno-builtin -fno-pic ${OPT:--O1} -fno-stack-protector \
      -fno-asynchronous-unwind-tables -DWINAPI= -DIMP= -Wall -Wextra -Wno-unused-function -Wno-unused-parameter \
      -I src test/harness.c -o test/harness
