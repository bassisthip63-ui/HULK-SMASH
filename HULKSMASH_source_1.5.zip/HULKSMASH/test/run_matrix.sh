#!/bin/sh
# run_matrix.sh GTAIV.exe WORKDIR   -> builds flat images of the exe and runs the harness over a matrix of
# optimisation levels, load bases and MaxArchives values. Prints one summary line per run, exits non-zero on any failure.
set -u
cd "$(dirname "$0")/.."
EXE=$1; W=$2; mkdir -p "$W"
for b in 400000 20000000 30000000; do python3 test/mkimage.py "$EXE" 0x$b "$W/img_$b.bin" >/dev/null; done
rc=0
for opt in -O1 -O2; do
  OPT=$opt sh test/build_test.sh || exit 2
  for cfg in "400000 20000000 255" "400000 20000000 256" "400000 20000000 300" "400000 20000000 511" "400000 20000000 512" \
             "400000 20000000 1023" "400000 20000000 2047" "400000 20000000 5000" "30000000 20000000 1023" "30000000 20000000 2047" "20000000 30000000 511"; do
    set -- $cfg
    # the image that gets patched is a fresh copy at base $1; the stock reference sits at base $2
    out=$(./test/harness "$W/img_$2.bin" 0x$2 "$W/img_$1.bin" 0x$1 "$W" $3 2>&1); r=$?
    tot=$(echo "$out" | grep '^TOTAL' || echo "(no totals: $(echo "$out" | tail -1))")
    bits=$(echo "$out" | grep '^B = ' || true)
    printf '%s base=%s max=%s  rc=%s  %s  %s\n' "$opt" "$1" "$3" "$r" "$tot" "$bits"
    [ $r -eq 0 ] || { rc=1; echo "$out" | grep -E 'FAIL|differences' | grep -v ' 0 differences' | head -5; }
  done
done
exit $rc
