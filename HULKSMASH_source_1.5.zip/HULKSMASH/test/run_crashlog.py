#!/usr/bin/env python3
"""run_crashlog.py GTAIV.exe WORKDIR
Runs the crash-logger and archive-usage tests (harness.c: crashlog_tests, usage_tests) on a flat image of a real exe, in several configurations:
  - default (section absent), explicit Enabled=1, Enabled=0, registration failure
  - independent of the patch sections: archive section off, all sections on, nothing enabled, unsupported exe (plugin refuses to patch)
  - both optimisation levels
Each scenario gets a fresh work directory. The harness prints TOTAL: pass=N fail=M and exits non-zero on any failure."""
import os, struct, subprocess, sys, shutil
exe, W = sys.argv[1], sys.argv[2]
here = os.path.dirname(os.path.abspath(__file__))
os.makedirs(W, exist_ok=True)
raw = open(exe, 'rb').read()
pe = struct.unpack_from('<I', raw, 0x3c)[0]
soi, = struct.unpack_from('<I', raw, pe + 24 + 56)
ref = os.path.join(W, 'cl_ref_20000000.bin'); src = os.path.join(W, 'cl_src_400000.bin'); bad = os.path.join(W, 'cl_unsupported_400000.bin')
subprocess.check_call([sys.executable, os.path.join(here, 'mkimage.py'), exe, '0x20000000', ref], stdout=subprocess.DEVNULL)
subprocess.check_call([sys.executable, os.path.join(here, 'mkimage.py'), exe, '0x400000', src], stdout=subprocess.DEVNULL)
img = bytearray(open(src, 'rb').read())[:soi]
img2 = bytearray(img); struct.pack_into('<I', img2, pe + 8, 0xDEADBEEF)          # a timestamp no profile knows
open(bad, 'wb').write(img2)

ARCH = '[ArchiveLimit]\nEnabled=1\nMaxArchives=1023\n'
SCEN = [
    ('default (no [CrashLog] section)', ARCH, src, 'on'),
    ('Enabled=1',                       ARCH + '[CrashLog]\nEnabled=1\n', src, 'on'),
    ('Enabled=0',                       ARCH + '[CrashLog]\nEnabled=0\n', src, 'off'),
    ('registration fails',              ARCH + '[CrashLog]\nEnabled=1\n[Harness]\nVehFail=1\n', src, 'on'),
    ('archive section off',             '[ArchiveLimit]\nEnabled=0\n[CrashLog]\nEnabled=1\n', src, 'on'),
    ('MaxArchives=255 (nothing to patch)', '[ArchiveLimit]\nEnabled=1\nMaxArchives=255\n', src, 'on'),
    ('all sections on',                 ARCH + '[VehicleBudget]\nEnabled=1\nValue=120000000\n[PedBudget]\nEnabled=1\nValue=75000000\n[CrashLog]\nEnabled=1\n', src, 'on'),
    ('unsupported exe: patches refused, logger still on', ARCH, bad, 'on'),
    ('MaxArchives=511',                 '[ArchiveLimit]\nEnabled=1\nMaxArchives=511\n', src, 'on'),
    ('MaxArchives=2047',                '[ArchiveLimit]\nEnabled=1\nMaxArchives=2047\n', src, 'on'),
    ('ReportUsage=0 (archive section on)', '[ArchiveLimit]\nEnabled=1\nMaxArchives=1023\nReportUsage=0\n[CrashLog]\nEnabled=1\n', src, 'on'),
    ('ReportUsage=0 (archive section off)', '[ArchiveLimit]\nEnabled=0\nReportUsage=0\n[CrashLog]\nEnabled=1\n', src, 'on'),
    ('crash log off, usage report on',  ARCH + '[CrashLog]\nEnabled=0\n', src, 'off'),
    ('nothing enabled but the usage report', '[ArchiveLimit]\nEnabled=0\n[CrashLog]\nEnabled=0\n', src, 'off'),
]
fails = 0
for opt in ('-O1', '-O2'):
    env = dict(os.environ, OPT=opt)
    subprocess.check_call(['sh', os.path.join(here, 'build_test.sh')], env=env)
    for i, (name, ini, imgpath, mode) in enumerate(SCEN):
        d = os.path.join(W, 'cl_%s_%d' % (opt[1:], i))
        shutil.rmtree(d, ignore_errors=True); os.makedirs(d)
        ip = os.path.join(d, 'scenario.ini'); open(ip, 'w').write(ini + ('' if '[Harness]' in ini else '[Harness]\n') + 'CrashLogTest=1\nSkipBudgetCheck=0\n')
        r = subprocess.run([os.path.join(here, 'harness'), ref, '0x20000000', imgpath, '0x400000', d, '@' + ip], capture_output=True, text=True)
        tot = [l for l in r.stdout.splitlines() if l.startswith('TOTAL')]
        ok = r.returncode == 0 and tot and tot[0].endswith('fail=0')
        fl = [l for l in r.stdout.splitlines() if 'FAIL' in l][:4]
        print('%s %-52s %-4s rc=%s  %s' % (opt, name, mode, r.returncode, (tot[0] if tot else '(no totals) ' + r.stdout[-200:].replace('\n', ' | ') + r.stderr[-200:])))
        for l in fl: print('      ', l)
        if not ok: fails += 1
print('FAILED scenarios:', fails)
sys.exit(1 if fails else 0)
