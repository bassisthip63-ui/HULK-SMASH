#!/usr/bin/env python3
"""audit.py PRISTINE.bin PATCHED.bin BASE [NEWTABLE NENTRIES] [arch=0] [veh=VALUE] [ped=VALUE]
refcheck=0 : do not require the budget variable's code references to match the plan (images with deliberately corrupted references)
arch=0 : the archive section was not applied (nothing of it may have changed); default arch=1
veh= / ped= : the expected new value of the vehicle / ped budget dword; leave out when it must be untouched
(optional) NEWTABLE/NENTRIES: the allocated table address and number of usable entries (= index mask); when given, every patched
reference is also checked against the remap formula  body: NEWTABLE + (old-table)   end pointer: NEWTABLE + NENTRIES*0xA0 + (old-END)
Proves the plugin changed exactly the planned bytes (taken from src/profiles_gen.h) and that no reference into the old
255-entry table was left behind. PRISTINE and PATCHED are flat images (test/mkimage.py) loaded at BASE.
The profile (P1070 / P1080 / P1259) is picked by the image's PE timestamp."""
import re, struct, sys, os
opts = dict(a.split('=', 1) for a in sys.argv[1:] if '=' in a)
argv = [a for a in sys.argv if '=' not in a]
ARCH = opts.get('arch', '1') != '0'
pri = open(argv[1], 'rb').read(); pat = open(argv[2], 'rb').read(); base = int(argv[3], 0)
# mkimage can emit a few bytes past SizeOfImage when a protected exe has an unaligned SizeOfImage; compare the mapped part
pri = pri[:len(pat)]
assert len(pri) == len(pat)
PREF = 0x400000
d = (base - PREF) & 0xffffffff
hdr = open(os.path.join(os.path.dirname(os.path.abspath(__file__)), '..', 'src', 'profiles_gen.h')).read()

pe = struct.unpack_from('<I', pri, 0x3c)[0]
ts, = struct.unpack_from('<I', pri, pe + 8)
tag = None
newt = int(argv[4], 0) if len(argv) > 5 else None
nent = int(argv[5], 0) if len(argv) > 5 else None
m = re.findall(r'static const Profile (\w+) = \{ "[^"]*", 0x([0-9a-f]+)u, 0x([0-9a-f]+)u, 0x([0-9a-f]+)u,', hdr)
prof = {t: (int(a, 16), int(b, 16), int(c, 16)) for t, a, b, c in m}
if tag is None:
    tag = [t for t, (a, _, _) in prof.items() if a == ts][0]
tstamp, soi, table_va = prof[tag]
ENC_END = {'P1070': 0, 'P1080': 0, 'P1259': 0x4fb000}[tag]       # ciphertext prefix of .text (1.2.0.59): not code, not audited
END = table_va + 255 * 0xA0

def block(name):
    return re.search(r'static const \w+ %s_%s\[\] = \{(.*?)\n\};' % (tag, name), hdr, re.S).group(1)
body = [(int(a, 16), int(b, 16)) for a, b in re.findall(r'\{0x([0-9a-f]{8}),0x([0-9a-f]{8})\}', block('body'))]
sent = [(int(a, 16), int(b, 16)) for a, b in re.findall(r'\{0x([0-9a-f]{8}),0x([0-9a-f]{8})\}', block('sent'))]
hooks = [(int(a, 16), int(b)) for a, b in re.findall(r'\{ 0x([0-9a-f]{8}), (\d+), \d+, \{', block('hooks'))]
bps = [(int(a, 16), int(l), int(o), int(k)) for a, l, o, k in re.findall(r'\{ 0x([0-9a-f]{8}), (\d+), (\d+), (\d), \d+, \{', block('bp'))]


# every relocated dword in an image (the exe has a normal reloc table, so every absolute address in code/data is listed)
def relocs_of(img):
    rva, size = struct.unpack_from('<II', img, pe + 24 + 96 + 5 * 8)
    p = rva; out = []
    while p < rva + size:
        pg, blk = struct.unpack_from('<II', img, p)
        if blk == 0: break
        for k in range((blk - 8) // 2):
            e, = struct.unpack_from('<H', img, p + 8 + 2 * k)
            if e >> 12 == 3: out.append(pg + (e & 0xfff))
        p += blk
    return out
rel = relocs_of(pri)
rel_p = relocs_of(pat)

bv = {}
for what in ('ped', 'veh'):
    mm = re.search(r'static const BudgetVar %s_%s = \{ 0x([0-9a-f]+), (\d+)u, (\d+), \{([^}]*)\}' % (tag, what), hdr)
    bv[what] = (int(mm.group(1), 16), int(mm.group(2)), [int(x, 16) for x in mm.group(4).split(',')][:int(mm.group(3))])

allowed = []
if ARCH:
    for s, _ in body + sent: allowed.append((s - PREF, 4))
    for va, ln in hooks: allowed.append((va - PREF, ln))
    for va, ln, off, kind in bps: allowed.append((va - PREF + off, 4 if kind == 0 else 1))
budget_ok = True
for what in ('ped', 'veh'):
    va, stock, refs = bv[what]
    got, = struct.unpack_from('<I', pat, va - PREF); was, = struct.unpack_from('<I', pri, va - PREF)
    want = int(opts[what], 0) if what in opts else was
    if what in opts and want != was: allowed.append((va - PREF, 4))
    # independent cross-check straight from the relocation table: which code points at the variable, in the pristine and the patched image
    found = sorted(PREF + s for s in rel if PREF + s >= ENC_END and struct.unpack_from('<I', pri, s)[0] == va + d)
    found_p = sorted(PREF + s for s in rel_p if PREF + s >= ENC_END and struct.unpack_from('<I', pat, s)[0] == va + d)
    refs_ok = found == sorted(refs) == found_p
    print("%s budget @%x: pristine %d -> patched %d (expected %d) %s; %d code refs from the reloc table, plan lists %d: %s"
          % (what, va, was, got, want, "ok" if got == want else "WRONG", len(found), len(refs), "match" if refs_ok else "MISMATCH"))
    budget_ok = budget_ok and got == want and (refs_ok or opts.get('refcheck') == '0')

cover = bytearray(len(pri))
for r, l in allowed:
    for i in range(r, r + l): cover[i] = 1
diffs = [i for i in range(len(pri)) if pri[i] != pat[i]]
stray = [i for i in diffs if not cover[i]]
print("%s: archive section %s; planned %d body refs, %d end-pointer refs, %d hooks, %d byte patches; changed bytes: %d"
      % (tag, "APPLIED" if ARCH else "not applied", len(body), len(sent), len(hooks), len(bps), len(diffs)))
print("changed bytes outside the planned regions:", len(stray), ("-> " + ", ".join("%x" % (PREF + i) for i in stray[:10]) if stray else ""))
unchanged = [(hex(PREF + r), l) for r, l in allowed if all(pri[i] == pat[i] for i in range(r, r + l))]
print("planned regions that did NOT change:", len(unchanged), unchanged[:5])

ok = not stray and not unchanged and budget_ok
if ARCH:
    lo, hi, tail = table_va + d, END + d, END + 0x100 + d
    pri_body, pri_tail = [], []
    for site in rel:
        va = site + PREF
        if va < ENC_END: continue
        v, = struct.unpack_from('<I', pri, site)
        if lo <= v < hi: pri_body.append(va)
        elif hi <= v < tail: pri_tail.append((va, v - d))
    body_sites = sorted(s for s, _ in body)
    print("pristine references into the table body: %d (plan covers %d) -> %s"
          % (len(pri_body), len(body_sites), "match" if sorted(pri_body) == body_sites else "MISMATCH"))
    left_body = [(PREF + s) for s in rel_p if PREF + s >= ENC_END and lo <= struct.unpack_from('<I', pat, s)[0] < hi]
    print("references still pointing into the old table body after patching:", len(left_body), [hex(x) for x in left_body[:5]])
    sent_sites = {s for s, _ in sent}
    left_tail = [(va, v) for va, v in pri_tail if va not in sent_sites]
    gone = [va for va, v in pri_tail if va in sent_sites and struct.unpack_from('<I', pat, va - PREF)[0] - d >= END and struct.unpack_from('<I', pat, va - PREF)[0] - d < END + 0x100]
    print("end-pointer references remapped: %d of %d planned; still inside the old tail area: %d" % (len(sent_sites) - len(gone), len(sent_sites), len(gone)))
    print("references into the %x..%x area that are deliberately left alone (standalone variables / other objects):" % (END, END + 0x100))
    for va, v in left_tail: print("   site %x -> %x (END%+d)" % (va, v, v - END))
    formula_bad = []
    if newt is not None:
        for site, old in body:
            new, = struct.unpack_from('<I', pat, site - PREF)
            if new != newt + (old - table_va): formula_bad.append((hex(site), hex(new)))
        for site, old in sent:
            new, = struct.unpack_from('<I', pat, site - PREF)
            if new != newt + nent * 0xA0 + (old - END): formula_bad.append((hex(site), hex(new)))
        print("remap formula checked at %d sites (table %#x, %d entries): %d wrong" % (len(body) + len(sent), newt, nent, len(formula_bad)))
    sent_ok = len(pri_tail) - len(left_tail) == len(sent_sites) and not gone
    ok = ok and not left_body and sorted(pri_body) == body_sites and sent_ok and not formula_bad
print("AUDIT", "PASSED" if ok else "FAILED")
sys.exit(0 if ok else 1)
