#!/usr/bin/env python3
"""mkimage.py GTAIV.exe BASE out.bin  -> flat loaded image (sections at their RVAs, HIGHLOW relocs applied for BASE)"""
import struct, sys
exe = open(sys.argv[1],'rb').read(); base = int(sys.argv[2],0); out = sys.argv[3]
pe = struct.unpack_from('<I', exe, 0x3c)[0]
nsec, = struct.unpack_from('<H', exe, pe+6); optsz, = struct.unpack_from('<H', exe, pe+20); opt = pe+24
pref, = struct.unpack_from('<I', exe, opt+28); soi, = struct.unpack_from('<I', exe, opt+56); soh, = struct.unpack_from('<I', exe, opt+60)
img = bytearray(soi)
img[:soh] = exe[:soh]
for i in range(nsec):
    o = opt+optsz+i*40
    vs,va,rs,ro = struct.unpack_from('<IIII', exe, o+8)
    img[va:va+min(rs,vs)] = exe[ro:ro+min(rs,vs)]
rva, size = struct.unpack_from('<II', exe, opt+96+5*8)
delta = (base - pref) & 0xffffffff
p = rva; end = rva+size; n = 0
while p < end:
    pg, blk = struct.unpack_from('<II', img, p)
    if blk == 0: break
    for k in range((blk-8)//2):
        e, = struct.unpack_from('<H', img, p+8+2*k)
        t, off = e >> 12, e & 0xfff
        if t == 3:
            a = pg+off; v, = struct.unpack_from('<I', img, a); struct.pack_into('<I', img, a, (v+delta) & 0xffffffff); n += 1
    p += blk
open(out,'wb').write(img)
print("image %s base 0x%x, %d relocs applied" % (out, base, n))
