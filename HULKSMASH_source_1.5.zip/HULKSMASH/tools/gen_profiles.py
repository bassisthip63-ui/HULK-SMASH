#!/usr/bin/env python3
"""Generate src/profiles_gen.h : one 'profile' per supported GTAIV.exe build.

A profile holds everything that is specific to one exe build:
  * identity (PE timestamp + SizeOfImage)
  * where the 255-entry archive table lives, and every instruction that references it
  * the hook sites (original bytes to verify + stub machine code with explicit fixups)
  * in-place immediate patches (shift counts / masks)

usage: gen_profiles.py <exe 1.0.7.0> <exe 1.0.8.0> <exe 1.2.0.59> <out.h>
Every byte listed below is checked against the real exe; the generator aborts on any difference.
"""
import pickle, re, struct, subprocess, sys

import os
DATA = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'data') + os.sep    # pickled (site, value) lists of every relocated reference into each build's archive table
PH = {'MASK': 0xA5A5A501, 'NMASK': 0xA5A5A502, 'MUL': 0xA5A5A504}
SH_PLACEHOLDER = 0x5A
FIXKIND = {'MASK': 0, 'NMASK': 1, 'MUL': 2, 'SHB': 3, 'SHC': 4, 'BACK': 5}
BPKIND = {'MASK32': 0, 'SHB': 1, 'SHC': 2, 'CONST': 3}


# ------------------------------------------------------------------------------------------- PE helpers
class Exe:
    def __init__(self, path):
        self.d = open(path, 'rb').read()
        d = self.d
        e = struct.unpack_from('<I', d, 0x3c)[0]
        assert d[e:e+4] == b'PE\0\0'
        self.nsec, = struct.unpack_from('<H', d, e+6)
        self.ts, = struct.unpack_from('<I', d, e+8)
        optsz, = struct.unpack_from('<H', d, e+20)
        opt = e + 24
        self.base, = struct.unpack_from('<I', d, opt+28)
        self.soi, = struct.unpack_from('<I', d, opt+56)
        self.secs = []
        for i in range(self.nsec):
            nm, vs, va, rs, ro = struct.unpack_from('<8sIIII', d, opt+optsz+i*40)
            self.secs.append((nm, vs, self.base+va, rs, ro))

    def relocs(self):
        """VAs of every HIGHLOW-relocated dword"""
        d = self.d
        e = struct.unpack_from('<I', d, 0x3c)[0]
        rva, size = struct.unpack_from('<II', d, e + 24 + 96 + 5 * 8)
        base_va = self.base + rva
        out, p = [], None
        for nm, vs, sva, rs, ro in self.secs:
            if sva <= base_va < sva + max(vs, rs):
                p = ro + (base_va - sva)
        end = p + size
        while p < end:
            page, blk = struct.unpack_from('<II', d, p)
            if blk == 0:
                break
            for k in range((blk - 8) // 2):
                w, = struct.unpack_from('<H', d, p + 8 + 2 * k)
                if w >> 12 == 3:
                    out.append(self.base + page + (w & 0xfff))
            p += blk
        return out

    def rd(self, va, n):
        for nm, vs, sva, rs, ro in self.secs:
            if sva <= va < sva+vs:
                assert va-sva+n <= rs, "not file backed %x" % va
                return self.d[ro+va-sva: ro+va-sva+n]
        raise SystemExit("va %x not in image" % va)


def assemble(line):
    p = subprocess.run(["llvm-mc", "-triple=i686-pc-windows-msvc", "-x86-asm-syntax=intel", "--show-encoding"],
                       input=".intel_syntax noprefix\n" + line + "\n", capture_output=True, text=True)
    if p.returncode:
        sys.exit("llvm-mc failed on %r:\n%s" % (line, p.stderr))
    m = re.search(r"encoding: \[([^\]]*)\]", p.stdout)
    if not m:
        sys.exit("no encoding for %r:\n%s" % (line, p.stdout))
    return bytes(int(x, 16) for x in m.group(1).split(","))


def build_stub(lines):
    """-> (code bytes, [(offset, kind)], has_back)"""
    code = b''
    fix = []
    back = False
    for ln in lines:
        if ln == 'BACK':
            fix.append((len(code) + 1, 'BACK'))
            code += b'\xE9\0\0\0\0'
            back = True
            continue
        tok = re.search(r'@(MASK|NMASK|MUL|SHB|SHC)\b', ln)
        if tok:
            k = tok.group(1)
            val = ('0x%X' % PH[k]) if k in PH else ('0x%X' % SH_PLACEHOLDER)
            b = assemble(ln.replace(tok.group(0), val))
            size = 4 if k in PH else 1
            # the immediate must be the last operand, so it sits at the very end of the encoding
            imm = (PH[k] if k in PH else SH_PLACEHOLDER).to_bytes(size, 'little')
            assert b.endswith(imm), "immediate not at end of %r: %s" % (ln, b.hex())
            fix.append((len(code) + len(b) - size, k))
            code += b
        else:
            code += assemble(ln)
    assert not (back and code.endswith(b'\xC3')), "stub both returns and jumps back"
    return code, fix, back


# ------------------------------------------------------------------------------------------- profile specs
def spec_1080():
    return dict(
        tag='P1080', name='GTAIV.exe 1.0.8.0',
        table_va=0x1399800,
        budget=dict(ped=0xf49b94, veh=0xf49b98),
        tablerefs=DATA + 'tablerefs_1080.pkl',
        enc_end=0,
        sentinel=[0x495565, 0xa22b20, 0xa22bd5, 0xa22c3e, 0xa22d3f, 0xa230f4, 0xa23152, 0xcc3307],
        exclude=[],
        hooks=[
            # name, va, len, expected bytes, stub lines
            ('SETTER', 0xb6c3e0, 38,
             '0fb64104 8b542404 c1e208 0bc2 8b542408 894104 8b4108 03d2 83e003 03d2 0bc2 894108 c20800',
             ['mov eax, dword ptr [ecx+4]', 'and eax, @MASK', 'imul edx, dword ptr [esp+4], @MUL', 'or eax, edx',
              'mov dword ptr [ecx+4], eax', 'mov edx, dword ptr [esp+8]', 'add edx, edx', 'mov eax, dword ptr [ecx+8]',
              'and eax, 3', 'add edx, edx', 'or eax, edx', 'mov dword ptr [ecx+8], eax', 'ret 8']),
            ('ACCESSOR', 0x8b4c5a, 6, '0fb644ca04 c3',
             ['mov eax, dword ptr [edx+ecx*8+4]', 'and eax, @MASK', 'ret']),
            ('H3', 0xb6ca19, 5, '0fb644c104',
             ['mov eax, dword ptr [ecx+eax*8+4]', 'and eax, @MASK', 'BACK']),
            ('H4', 0xb6cb2a, 8, '0fb65604 3b542444',
             ['mov edx, dword ptr [esi+4]', 'and edx, @MASK', 'cmp edx, dword ptr [esp+0x44]', 'BACK']),
            ('H6', 0xb6cb55, 7, '8a442410 884e04',
             ['mov al, byte ptr [esp+0x10]', 'push edx', 'mov edx, dword ptr [esi+4]', 'and edx, @NMASK',
              'and ecx, @MASK', 'or edx, ecx', 'mov dword ptr [esi+4], edx', 'pop edx', 'BACK']),
            ('H7', 0xb6cd3c, 5, 'c6441604ff',
             ['or dword ptr [esi+edx+4], @MASK', 'BACK']),
            ('H8', 0xb6d08d, 7, '0fb64004 8d0c80',
             ['mov eax, dword ptr [eax+4]', 'and eax, @MASK', 'lea ecx, [eax+eax*4]', 'BACK']),
            ('H9', 0xb6d0bc, 7, '0fb64204 8d0480',
             ['mov eax, dword ptr [edx+4]', 'and eax, @MASK', 'lea eax, [eax+eax*4]', 'BACK']),
            ('H10', 0xb6d11c, 5, '0fb644c204',
             ['mov eax, dword ptr [edx+eax*8+4]', 'and eax, @MASK', 'BACK']),
            ('H11', 0xb6d1bd, 7, '0fb64004 8d0c80',
             ['mov eax, dword ptr [eax+4]', 'and eax, @MASK', 'lea ecx, [eax+eax*4]', 'BACK']),
            ('H12', 0xcb1b23, 8, '0fb66f04 8d6cad00',
             ['mov ebp, dword ptr [edi+4]', 'and ebp, @MASK', 'lea ebp, [ebp+ebp*4]', 'BACK']),
        ],
        # name, va of the instruction, expected instruction bytes, offset of the immediate, kind, const value
        bpatches=[
            ('H5', 0xb6cb51, '8a4c2444', 0, 'CONST', 0x8b),     # mov cl,[esp+44] -> mov ecx,[esp+44]
            ('D1', 0xb6c34d, '81e1ff000000', 2, 'MASK32', 0),   # and ecx,0xff -> and ecx,MASK
            ('D2', 0xb6c359, 'c1e808', 2, 'SHB', 0),            # shr eax,8 -> shr eax,B
            ('D3', 0xa22cd0, 'c1e018', 2, 'SHC', 0),            # shl eax,24 -> shl eax,32-B
        ])


def spec_1070():
    """1.0.7.0 was compiled from the same source as 1.0.8.0: every function that touches the archive table is byte-identical
    (apart from relocations / call displacements) and merely sits at a different address. The profile is therefore the 1.0.8.0
    profile with every address translated through the function map in tools/data/fnmap_1070.pkl (built by matching each
    1.0.8.0 function, relocations masked, against the 1.0.7.0 code). The generator still verifies every expected byte
    against the real 1.0.7.0 exe, and the reference list comes from the 1.0.7.0 relocation table itself."""
    fm = pickle.load(open(DATA + 'fnmap_1070.pkl', 'rb'))

    def tr(a):
        for old_s, old_e, new_s in fm:
            if old_s <= a < old_e:
                return new_s + (a - old_s)
        raise KeyError('%x not inside a mapped function' % a)
    sp = spec_1080()
    sp['tag'] = 'P1070'
    sp['name'] = 'GTAIV.exe 1.0.7.0'
    sp['table_va'] = 0x121dfd8
    sp['budget'] = dict(ped=0xf22b5c, veh=0xf22b60)
    sp['tablerefs'] = DATA + 'tablerefs_1070.pkl'
    sp['sentinel'] = [tr(a) for a in sp['sentinel']]
    sp['hooks'] = [(n, tr(va), ln, exp, lines) for (n, va, ln, exp, lines) in sp['hooks']]
    sp['bpatches'] = [(n, tr(va), exp, io, k, v) for (n, va, exp, io, k, v) in sp['bpatches']]
    return sp


def spec_1259():
    return dict(
        tag='P1259', name='GTAIV.exe 1.2.0.59',
        table_va=0x12fb3b8,
        budget=dict(ped=0x10496d8, veh=0x10496dc),
        tablerefs=DATA + 'tablerefs_1259.pkl',
        enc_end=0x4fb000,          # .text prefix 0x401000-0x4fb000 is encrypted on disk; nothing we need is in it
        sentinel=[0x5c2e2f, 0xa95af4, 0xa95c1c, 0xa95e58, 0xa96160, 0xa95c5d, 0xa95d77, 0xc799e7],
        exclude=[],
        hooks=[
            ('SETTER', 0xa95750, 8, '0fb65104 8b442404',
             ['mov edx, dword ptr [ecx+4]', 'and edx, @MASK', 'mov eax, dword ptr [esp+4]', 'BACK']),
            ('ACCESSOR', 0x8d8399, 6, '0fb644c804 c3',
             ['mov eax, dword ptr [eax+ecx*8+4]', 'and eax, @MASK', 'ret']),
            ('GETHANDLE', 0xa9431b, 6, '0fb6c8 c1e808',
             ['mov ecx, eax', 'and ecx, @MASK', 'shr eax, @SHB', 'BACK']),
            ('H3', 0xa94b39, 5, '0fb644d004',
             ['mov eax, dword ptr [eax+edx*8+4]', 'and eax, @MASK', 'BACK']),
            ('H4', 0xa9515f, 8, '0fb64604 3b442448',
             ['mov eax, dword ptr [esi+4]', 'and eax, @MASK', 'cmp eax, dword ptr [esp+0x48]', 'BACK']),
            # the index argument is loaded as a dword and stored later with 'mov [esi+4],al' (kept): this stub stores
            # the extra index bits (ecx is dead here, edx is saved)
            ('H6', 0xa9518e, 5, '8b442448 57',
             ['mov eax, dword ptr [esp+0x48]', 'push edi', 'push edx', 'mov edx, dword ptr [esi+4]', 'and edx, @NMASK',
              'mov ecx, eax', 'and ecx, @MASK', 'or edx, ecx', 'mov dword ptr [esi+4], edx', 'pop edx', 'BACK']),
            ('H7', 0xa9501d, 5, 'c6443004ff',
             ['or dword ptr [eax+esi+4], @MASK', 'BACK']),
            ('H8', 0xa94d0d, 7, '0fb64004 8d0480',
             ['mov eax, dword ptr [eax+4]', 'and eax, @MASK', 'lea eax, [eax+eax*4]', 'BACK']),
            ('H9', 0xa94d3b, 7, '0fb64e04 8d0c89',
             ['mov ecx, dword ptr [esi+4]', 'and ecx, @MASK', 'lea ecx, [ecx+ecx*4]', 'BACK']),
            ('H10', 0xa94f3e, 5, '0fb644d004',
             ['mov eax, dword ptr [eax+edx*8+4]', 'and eax, @MASK', 'BACK']),
            ('H11', 0xa943cd, 7, '0fb64004 8d1480',
             ['mov eax, dword ptr [eax+4]', 'and eax, @MASK', 'lea edx, [eax+eax*4]', 'BACK']),
            ('H12', 0xd5b544, 9, '0fb64304 b901000000',
             ['mov eax, dword ptr [ebx+4]', 'and eax, @MASK', 'mov ecx, 1', 'BACK']),
        ],
        bpatches=[
            ('SETSHL', 0xa95758, 'c1e008', 2, 'SHB', 0),        # shl eax,8 (position) -> shl eax,B
            ('D3', 0xa95b8e, 'c1e018', 2, 'SHC', 0),            # shl eax,24 (handle base) -> shl eax,32-B
        ])


# ------------------------------------------------------------------------------------------- emit
def hexb(b):
    return ','.join('0x%02x' % x for x in b)


def emit_profile(spec, exe, out):
    tag = spec['tag']
    T = spec['table_va']
    END = T + 255 * 0xA0
    # --- table references
    tr = pickle.load(open(spec['tablerefs'], 'rb'))
    sent = set(spec['sentinel'])
    body, sentl = [], []
    for site, val in sorted(tr):
        if site < spec['enc_end'] and spec['enc_end']:
            continue                                   # ciphertext, not code
        # the pickle holds the on-disk values; re-read from the exe so the generator checks itself
        v = struct.unpack_from('<I', exe.rd(site, 4))[0]
        assert v == val, "reloc value differs at %x" % site
        if site in sent:
            assert END <= v < END + 0x100, "sentinel site %x has value %x" % (site, v)
            sentl.append((site, v))
        elif T <= v < END:
            body.append((site, v))
    assert len(sentl) == len(sent), "missing sentinel sites"
    assert len(body) == 35, "expected 35 body refs, got %d" % len(body)

    out.append('/* ---- profile %s : %s ---- */' % (tag, spec['name']))
    out.append('static const RefSite %s_body[] = {' % tag)
    out += ['  {0x%08x,0x%08x},' % x for x in body]
    out.append('};')
    out.append('static const RefSite %s_sent[] = {' % tag)
    out += ['  {0x%08x,0x%08x},' % x for x in sentl]
    out.append('};')

    # --- stubs + hooks
    hooks_c = []
    for i, (name, va, ln, exp, lines) in enumerate(spec['hooks']):
        expb = bytes.fromhex(exp.replace(' ', ''))
        got = exe.rd(va, ln)
        assert got == expb, "%s %s: exe has %s, spec says %s" % (tag, name, got.hex(), expb.hex())
        assert 5 <= ln <= 40
        code, fix, back = build_stub(lines)
        out.append('static const u8 %s_stub%d[] = {%s}; /* %s */' % (tag, i, hexb(code), name))
        out.append('static const Fix %s_fix%d[] = {%s};' % (
            tag, i, ','.join('{%d,%d}' % (o, FIXKIND[k]) for o, k in fix)))
        hooks_c.append((va, ln, i, got.ljust(40, b'\0'), name, back, len(code), len(fix)))
    out.append('static const StubDef %s_stubs[] = {' % tag)
    for (va, ln, i, orig, name, back, clen, nfix) in hooks_c:
        out.append('  { %s_stub%d, %d, %d, %s_fix%d, %d }, /* %s */' % (tag, i, clen, 1 if back else 0, tag, i, nfix, name))
    out.append('};')
    out.append('static const HookDef %s_hooks[] = {' % tag)
    for (va, ln, i, orig, name, back, clen, nfix) in hooks_c:
        out.append('  { 0x%08x, %d, %d, {%s} }, /* %s */' % (va, ln, i, hexb(orig), name))
    out.append('};')

    # --- byte patches
    out.append('static const BytePatch %s_bp[] = {' % tag)
    for (name, va, exp, immoff, kind, val) in spec['bpatches']:
        expb = bytes.fromhex(exp)
        assert exe.rd(va, len(expb)) == expb, "%s %s mismatch" % (tag, name)
        size = 4 if kind == 'MASK32' else 1
        assert immoff + size <= len(expb)
        out.append('  { 0x%08x, %d, %d, %d, %d, {%s} }, /* %s */' % (
            va, len(expb), immoff, BPKIND[kind], val, hexb(expb.ljust(8, b'\0')), name))
    out.append('};')

    # --- the two streaming memory budgets: plain dwords in .data that the game compares against
    rel = [r for r in exe.relocs() if not (spec['enc_end'] and r < spec['enc_end'])]
    for key, stock, expect_refs in (('ped', 50000000, 3), ('veh', 40000000, 4)):
        va = spec['budget'][key]
        assert struct.unpack('<I', exe.rd(va, 4))[0] == stock, "%s budget variable does not hold %d" % (key, stock)
        refs = sorted(r for r in rel if struct.unpack('<I', exe.rd(r, 4))[0] == va)
        assert len(refs) == expect_refs, "%s budget: %d code references, expected %d" % (key, len(refs), expect_refs)
        out.append('static const BudgetVar %s_%s = { 0x%08x, %du, %d, {%s} };' % (
            tag, key, va, stock, len(refs), ','.join('0x%08x' % r for r in refs + [0] * (4 - len(refs)))))

    out.append('static const Profile %s = { "%s", 0x%08xu, 0x%08xu, 0x%08xu,' % (tag, spec['name'], exe.ts, exe.soi, T))
    out.append('  %s_body, %d, %s_sent, %d, %s_stubs, %s_hooks, %d, %s_bp, %d, &%s_ped, &%s_veh };' % (
        tag, len(body), tag, len(sentl), tag, tag, len(hooks_c), tag, len(spec['bpatches']), tag, tag))
    out.append('')
    print('%s: %d body refs, %d table-end refs, %d hooks, %d byte patches (timestamp 0x%08x, size 0x%x)' % (
        tag, len(body), len(sentl), len(hooks_c), len(spec['bpatches']), exe.ts, exe.soi))


def main():
    exe_7, exe_a, exe_b, outp = sys.argv[1:5]
    out = ['/* generated by tools/gen_profiles.py - do not edit */',
           'typedef struct { unsigned site, target; } RefSite;',
           'typedef struct { unsigned char off, kind; } Fix;    /* kind: 0 MASK 1 NMASK 2 MUL 3 SHB 4 SHC 5 BACK */',
           'typedef struct { const unsigned char *code; unsigned char size, has_back; const Fix *fix; unsigned char nfix; } StubDef;',
           'typedef struct { unsigned va; unsigned char len, stub; unsigned char orig[40]; } HookDef;',
           'typedef struct { unsigned va; unsigned char len, immoff, kind, value; unsigned char orig[8]; } BytePatch; /* kind: 0 MASK32 1 SHB 2 SHC 3 CONST */',
           'typedef struct { unsigned va, stock; unsigned char nref; unsigned ref[4]; } BudgetVar;   /* a 32-bit streaming budget in .data and the code that reads it */',
           'typedef struct { const char *name; unsigned timestamp, sizeofimage, table_va;',
           '                 const RefSite *body; unsigned nbody; const RefSite *sent; unsigned nsent;',
           '                 const StubDef *stubs; const HookDef *hooks; unsigned nhooks;',
           '                 const BytePatch *bp; unsigned nbp;',
           '                 const BudgetVar *ped, *veh; } Profile;',
           '']
    emit_profile(spec_1070(), Exe(exe_7), out)
    emit_profile(spec_1080(), Exe(exe_a), out)
    emit_profile(spec_1259(), Exe(exe_b), out)
    out.append('static const Profile *const g_profiles[] = { &P1070, &P1080, &P1259 };')
    open(outp, 'w').write('\n'.join(out) + '\n')


if __name__ == '__main__':
    main()
