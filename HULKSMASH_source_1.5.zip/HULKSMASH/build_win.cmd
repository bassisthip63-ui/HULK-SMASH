@echo off
rem Build HULKSMASH.asi on Windows with LLVM (winget install LLVM.LLVM). Keep this folder on a short path.
set LLVM=C:\Program Files\LLVM\bin
cd /d "%~dp0" || exit /b 10
"%LLVM%\llvm-dlltool.exe" -m i386 -k -d build\kernel32.def -l build\kernel32.lib || exit /b 11
"%LLVM%\clang.exe" --target=i686-pc-windows-msvc -O2 -ffreestanding -fno-builtin -fno-stack-protector -fno-asynchronous-unwind-tables -fno-unwind-tables -Wall -Wextra -Wno-unused-function -c src\archive_limit.c -o build\archive_limit.obj || exit /b 12
"%LLVM%\lld-link.exe" /dll /nodefaultlib /entry:DllMain@12 /subsystem:windows,5.01 /machine:x86 /filealign:512 /opt:ref /opt:icf /dynamicbase /nxcompat /map:build\HULKSMASH.map /out:HULKSMASH.asi build\archive_limit.obj build\kernel32.lib || exit /b 13
dir HULKSMASH.asi
